#!/usr/bin/env bash
#
# Hospital data backup — Postgres + MinIO + .env + config/.
# Encrypts the bundle with the hospital's GPG public key and rotates
# 30-day local snapshots. Optional off-host rclone sync.
#
# Cron entry (run daily at 02:00 server time):
#
#   0 2 * * *  cd /opt/ohm && \
#                GPG_RECIPIENT=hospital-it@kauvery.example \
#                BACKUP_REMOTE_RCLONE=b2:my-bucket/ohm \
#                ./scripts/backup-hospital.sh >> /var/log/ohm-backup.log 2>&1
#
# What gets included
#   • Postgres logical dump (`pg_dump --format=custom`) — every patient,
#     visit, note, audit row.
#   • MinIO bucket mirror — every audio recording.
#   • .env + config/ — so a clean machine can rehydrate the same wizard.
#
# What's NOT included (recovered another way)
#   • Container images — pulled fresh from Docker Hub on restore.
#   • OHM Engine API key — re-issued by OHM. Email info@ohm.doctor.
#
# Restore procedure (verified — exercise quarterly)
#   1. Provision a clean server; install Docker + this deploy bundle.
#   2. ./deploy/hospital/setup.sh --mode <m> ...
#   3. docker compose up -d postgres redis minio
#   4. gpg --decrypt <latest-backup>.tar.gz.gpg | tar -xz -C /tmp
#   5. cat /tmp/<TS>/postgres.dump | docker compose exec -T postgres \
#          pg_restore -U postgres -d ohm --clean --if-exists --no-owner --no-acl
#   6. docker run --rm --network <project>_ohm-network -v /tmp/<TS>/minio:/data \
#          -e "MC_HOST_ohm=http://ohm-admin:<minio-pw>@minio:9000" \
#          minio/mc mirror /data ohm/ohm-audio
#   7. docker compose up -d
#   8. ./deploy/hospital/verify.sh — must show all checks pass.

set -Eeuo pipefail

# ─── Locking — concurrent runs corrupt each other ────────────────────
LOCKFILE="/tmp/ohm-backup.lock"
exec 9>"$LOCKFILE"
if ! flock -n 9; then
  echo "[ohm-backup] another run is in progress (lock $LOCKFILE). Exiting." >&2
  exit 1
fi

BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/ohm}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
DEST="$BACKUP_ROOT/$TIMESTAMP"
LOG_TAG="[ohm-backup $TIMESTAMP]"
SUCCESS_TOUCHFILE="${BACKUP_ROOT}/.last-success"

# Disk-space safety: refuse to start if less than 5 GB free on backup volume.
MIN_FREE_KB=5242880

# Clean up partial work on any error.
cleanup() {
  local rc=$?
  if [ $rc -ne 0 ]; then
    echo "$LOG_TAG ✗ Backup failed (rc=$rc) — cleaning up partial files in $DEST" >&2
    rm -rf "$DEST" 2>/dev/null || true
  fi
  exit $rc
}
trap cleanup EXIT

mkdir -p "$BACKUP_ROOT"

# ─── Pre-flight: disk space ──────────────────────────────────────────
FREE_KB=$(df -Pk "$BACKUP_ROOT" | awk 'NR==2 {print $4}')
if [ "${FREE_KB:-0}" -lt "$MIN_FREE_KB" ]; then
  echo "$LOG_TAG ✗ Only ${FREE_KB}KB free on $BACKUP_ROOT, need ≥${MIN_FREE_KB}KB." >&2
  exit 2
fi

# ─── Pre-flight: working directory ───────────────────────────────────
cd "$(dirname "${BASH_SOURCE[0]}")/.."

# ─── Pre-flight: Postgres container actually running ─────────────────
PG_STATE=$(docker compose ps --format '{{.Service}} {{.State}}' 2>/dev/null \
  | awk '$1 == "postgres" {print $2}')
if [ "${PG_STATE:-}" != "running" ]; then
  echo "$LOG_TAG ✗ Postgres container state='${PG_STATE:-not-found}'. Abort." >&2
  exit 3
fi

mkdir -p "$DEST/minio"

# ─── Stage 1: Postgres logical dump ──────────────────────────────────
echo "$LOG_TAG → pg_dump"
docker compose exec -T postgres pg_dump \
  -U "${POSTGRES_USER:-postgres}" \
  -d "${POSTGRES_DB:-ohm}" \
  --no-owner --no-acl \
  --format=custom --compress=9 \
  > "$DEST/postgres.dump"

PG_SIZE=$(wc -c < "$DEST/postgres.dump")
if [ "$PG_SIZE" -lt 1024 ]; then
  echo "$LOG_TAG ✗ pg_dump only $PG_SIZE bytes — looks empty. Abort." >&2
  exit 4
fi
echo "$LOG_TAG ✓ pg_dump $PG_SIZE bytes"

# ─── Stage 2: MinIO bucket mirror (audio recordings) ────────────────
STORAGE_DRIVER=$(grep -E '^STORAGE_DRIVER=' .env 2>/dev/null | cut -d= -f2- | tr -d '"' || echo "local")
if [ "$STORAGE_DRIVER" = "s3" ]; then
  echo "$LOG_TAG → mc mirror minio/${OHM_S3_BUCKET:-ohm-audio}"

  # Auto-detect Docker network name from compose. Default is
  # <project>_ohm-network; project defaults to dir basename.
  PROJECT_NAME=$(basename "$(pwd)" | tr '[:upper:] .' '[:lower:]__')
  NETWORK_NAME="${COMPOSE_PROJECT_NAME:-$PROJECT_NAME}_ohm-network"
  if ! docker network inspect "$NETWORK_NAME" >/dev/null 2>&1; then
    # Fallback: pick first network ending in -ohm-network
    NETWORK_NAME=$(docker network ls --format '{{.Name}}' | grep -E 'ohm-network$' | head -1)
  fi
  if [ -z "$NETWORK_NAME" ]; then
    echo "$LOG_TAG ✗ Cannot find the ohm Docker network. Is compose running?" >&2
    exit 5
  fi

  # URL-encode the MinIO password so special chars don't break the URL.
  MINIO_PW=$(grep -E '^MINIO_ROOT_PASSWORD=' .env 2>/dev/null | cut -d= -f2- | tr -d '"' || echo "")
  MINIO_PW_ENC=$(printf '%s' "$MINIO_PW" | python3 -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.stdin.read(), safe=""))')

  docker run --rm \
    --network "$NETWORK_NAME" \
    -e "MC_HOST_ohm=http://${MINIO_ROOT_USER:-ohm-admin}:${MINIO_PW_ENC}@minio:9000" \
    -v "$DEST/minio:/backup" \
    minio/mc:latest \
    mirror --overwrite "ohm/${OHM_S3_BUCKET:-ohm-audio}" /backup

  MINIO_FILES=$(find "$DEST/minio" -type f 2>/dev/null | wc -l | tr -d ' ')
  echo "$LOG_TAG ✓ minio $MINIO_FILES files"
else
  echo "$LOG_TAG ⊘ STORAGE_DRIVER=$STORAGE_DRIVER — skipping minio mirror"
fi

# ─── Stage 3: env + config/ + Caddyfile (rehydrate metadata) ────────
cp .env "$DEST/env.backup"
[ -d config ] && cp -r config "$DEST/config"
[ -f Caddyfile ] && cp Caddyfile "$DEST/Caddyfile"
[ -f docker-compose.yml ] && cp docker-compose.yml "$DEST/docker-compose.yml"

# ─── Stage 4: tarball ────────────────────────────────────────────────
TARBALL="$BACKUP_ROOT/ohm-hospital-$TIMESTAMP.tar.gz"
tar -C "$BACKUP_ROOT" -czf "$TARBALL" "$TIMESTAMP"
rm -rf "$DEST"
chmod 600 "$TARBALL"

# ─── Stage 5: optional GPG encrypt ───────────────────────────────────
if [ -n "${GPG_RECIPIENT:-}" ]; then
  echo "$LOG_TAG → encrypting for $GPG_RECIPIENT"
  ENCRYPTED="$TARBALL.gpg"
  if gpg --batch --yes --encrypt --recipient "$GPG_RECIPIENT" -o "$ENCRYPTED" "$TARBALL"; then
    rm -f "$TARBALL"
    TARBALL="$ENCRYPTED"
    chmod 600 "$TARBALL"
  else
    echo "$LOG_TAG ⚠ GPG encryption failed — keeping plaintext tarball." >&2
    echo "$LOG_TAG   Check 'gpg --list-keys $GPG_RECIPIENT' on this server." >&2
  fi
fi

TAR_SIZE=$(wc -c < "$TARBALL")
echo "$LOG_TAG ✓ tarball $TARBALL ($TAR_SIZE bytes)"

# ─── Stage 6: retention rotation ─────────────────────────────────────
DELETED=$(find "$BACKUP_ROOT" -maxdepth 1 -type f -name 'ohm-hospital-*.tar.gz*' \
  -mtime "+$RETENTION_DAYS" -print -delete 2>/dev/null | wc -l | tr -d ' ')
echo "$LOG_TAG ⊘ retention pruned $DELETED snapshots beyond ${RETENTION_DAYS} days"

# ─── Stage 7: optional off-host rclone sync ─────────────────────────
if [ -n "${BACKUP_REMOTE_RCLONE:-}" ]; then
  if command -v rclone >/dev/null 2>&1; then
    echo "$LOG_TAG → rclone copy $TARBALL → $BACKUP_REMOTE_RCLONE"
    if rclone copy --quiet --retries 3 "$TARBALL" "$BACKUP_REMOTE_RCLONE"; then
      echo "$LOG_TAG ✓ rclone synced off-host"
    else
      echo "$LOG_TAG ✗ rclone copy failed — local tarball still safe." >&2
      # Non-fatal: cron should still mark success since local backup is good.
    fi
  else
    echo "$LOG_TAG ⚠ BACKUP_REMOTE_RCLONE set but rclone not installed (apt install rclone)" >&2
  fi
fi

# ─── Stage 8: stamp last-success touchfile (for monitoring) ─────────
date -u +%s > "$SUCCESS_TOUCHFILE"
chmod 644 "$SUCCESS_TOUCHFILE"

# ─── Stage 9: optional webhook ping (Healthchecks.io etc.) ──────────
if [ -n "${BACKUP_PING_URL:-}" ]; then
  curl -fsS -m 10 --retry 3 "$BACKUP_PING_URL" >/dev/null 2>&1 \
    && echo "$LOG_TAG ✓ pinged $BACKUP_PING_URL" \
    || echo "$LOG_TAG ⚠ ping to $BACKUP_PING_URL failed"
fi

echo "$LOG_TAG ✓ done"
trap - EXIT
