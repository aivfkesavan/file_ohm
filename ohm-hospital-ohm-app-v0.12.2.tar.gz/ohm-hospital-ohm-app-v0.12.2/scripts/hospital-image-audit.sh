#!/usr/bin/env bash
#
# Hospital image leak audit.
#
# Runs against any built `devforallohmok/hospital:api-vX.Y.Z` image (or
# any image in the same family). Exits 0 only when the image is
# verifiably free of OHM IP. Wire into CI as a gate before pushing.
#
# What it catches
#   • Vendor names (Sarvam, Gemini, OpenAI, Anthropic, etc.)
#   • Prompt markers (psychiatry, clinical-foundation, specialty)
#   • Full reference datasets (icd10-full, loinc-full, snomed-full)
#   • Audio processing binaries (ffmpeg, ffprobe)
#   • Source maps (.js.map)
#   • Leaked .env files
#   • Hardcoded API keys (AIzaSy…, sk_…, dckr_pat_…)
#
# Usage
#   scripts/hospital-image-audit.sh                                  # default tag
#   scripts/hospital-image-audit.sh devforallohmok/hospital:api-v0.13.0
#   scripts/hospital-image-audit.sh --strict <image>                 # also fail on warnings

set -Eeuo pipefail

STRICT=false
IMAGE=""

while [ $# -gt 0 ]; do
  case "$1" in
    --strict) STRICT=true; shift ;;
    -h|--help) sed -n '2,24p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) IMAGE="$1"; shift ;;
  esac
done

IMAGE="${IMAGE:-devforallohmok/hospital:api-latest}"
SCRATCH="$(mktemp -d)"
trap 'rm -rf "$SCRATCH"' EXIT

echo "→ Auditing $IMAGE"
echo "  scratch: $SCRATCH"

if ! docker save "$IMAGE" -o "$SCRATCH/image.tar" 2>/dev/null; then
  echo "✗ Cannot save image '$IMAGE' — does it exist locally?" >&2
  echo "  Try: docker images | grep $(echo "$IMAGE" | cut -d: -f1)" >&2
  exit 2
fi

mkdir -p "$SCRATCH/fs"
tar -xf "$SCRATCH/image.tar" -C "$SCRATCH/fs"

# Each Docker layer is its own tar. Unpack them all into one merged tree.
mkdir -p "$SCRATCH/all"
find "$SCRATCH/fs" \( -name "layer.tar" -o -name "*.tar.gz" -o -name "*.tar" \) 2>/dev/null \
  | while read -r layer; do
      tar -xf "$layer" -C "$SCRATCH/all" 2>/dev/null || true
    done

FAIL=0
WARN=0
PASSES=0

# grep_textfiles searches every text-like file in the extracted image for
# a regex. Uses find -exec instead of xargs so massive file lists don't
# overflow ARG_MAX or get truncated. Scans .js/.json/.ts/.mjs/.cjs AND
# .prisma — the Prisma schema ships inside the image and used to leak
# vendor names in code comments.
grep_textfiles() {
  local pattern="$1"
  find "$SCRATCH/all" -type f \
    \( -name "*.js" -o -name "*.json" -o -name "*.ts" -o -name "*.mjs" \
       -o -name "*.cjs" -o -name "*.prisma" -o -name "*.sql" \) \
    -exec grep -lE "$pattern" {} + 2>/dev/null | head -10 || true
}

check_grep() {
  local label="$1"
  local pattern="$2"
  local hits
  hits=$(grep_textfiles "$pattern")
  if [ -n "$hits" ]; then
    echo "  ✗ $label hits:"
    echo "$hits" | sed 's|^|    |'
    FAIL=$((FAIL + 1))
  else
    echo "  ✓ $label clean"
    PASSES=$((PASSES + 1))
  fi
}

check_file_absent() {
  local label="$1"
  local glob="$2"
  local hits
  hits=$(find "$SCRATCH/all" -type f -name "$glob" 2>/dev/null | head -5 || true)
  if [ -n "$hits" ]; then
    echo "  ✗ $label found:"
    echo "$hits" | sed 's|^|    |'
    FAIL=$((FAIL + 1))
  else
    echo "  ✓ $label absent"
    PASSES=$((PASSES + 1))
  fi
}

check_path_absent() {
  local label="$1"
  local needle="$2"
  local hits
  hits=$(find "$SCRATCH/all" -path "*$needle*" 2>/dev/null | head -5 || true)
  if [ -n "$hits" ]; then
    echo "  ✗ $label found:"
    echo "$hits" | sed 's|^|    |'
    FAIL=$((FAIL + 1))
  else
    echo "  ✓ $label absent"
    PASSES=$((PASSES + 1))
  fi
}

# Soft check: warning only, not a hard fail (passes if --strict not set).
check_warn() {
  local label="$1"
  local pattern="$2"
  local hits
  hits=$(echo "$TEXT_FILES" | xargs grep -lE "$pattern" 2>/dev/null | head -5 || true)
  if [ -n "$hits" ]; then
    echo "  ⚠ $label hits:"
    echo "$hits" | sed 's|^|    |'
    WARN=$((WARN + 1))
    [ "$STRICT" = true ] && FAIL=$((FAIL + 1))
  else
    echo "  ✓ $label clean"
    PASSES=$((PASSES + 1))
  fi
}

echo ""
echo "── Vendor names (STT, LLM providers) ──"
check_grep "Sarvam reference"      "sarvam"
check_grep "Gemini reference"      "gemini"
check_grep "Anthropic reference"   "anthropic"
check_grep "Claude reference"      "\bclaude\b"
check_grep "Moonshot endpoint"     "moonshot"
check_grep "Together AI endpoint"  "together\\.ai"
check_grep "Groq endpoint"         "groq\\.com"
check_grep "Mistral endpoint"      "mistral\\.ai"
check_grep "OpenAI base URL"       "api\\.openai\\.com"
check_grep "Google AI Studio URL"  "aistudio|generativelanguage"

echo ""
echo "── Vendor SDK package names ──"
check_grep "@ai-sdk/* package"     "@ai-sdk/(anthropic|openai|google|mistral|together)"
check_grep "sarvamai package"      "sarvamai|sarvam-ai"

echo ""
echo "── Prompts / extraction logic ──"
check_grep "system prompt marker"   "systemPrompt|system_prompt|SYSTEM_PROMPT"
check_grep "psychiatry prompts"     "psychiatry-insights|extractPsychiatryInsights"
check_grep "clinical-foundation"    "clinical[- ]foundation"
check_grep "specialty-prompts file" "specialty[- ]prompts"
check_grep "cardiology prompt"      "cardiology[Pp]rompt"
check_grep "ICU prompt"             "icu[Pp]rompt|ICU_PROMPT"

echo ""
echo "── Full reference datasets (engine-only) ──"
check_file_absent "icd10-full.json"        "icd10-full.json"
check_file_absent "loinc-full.json"        "loinc-full.json"
check_file_absent "snomed-full.json"       "snomed-full.json"

# Also flag any single .json file > 1 MB (likely a leaked full dataset).
BIG_JSON=$(find "$SCRATCH/all" -type f -name "*.json" -size +1M 2>/dev/null | head -5 || true)
if [ -n "$BIG_JSON" ]; then
  echo "  ⚠ Suspiciously large JSON files (>1 MB — could be a full dataset):"
  echo "$BIG_JSON" | sed 's|^|    |'
  WARN=$((WARN + 1))
  [ "$STRICT" = true ] && FAIL=$((FAIL + 1))
else
  echo "  ✓ No JSON file > 1 MB"
  PASSES=$((PASSES + 1))
fi

echo ""
echo "── Engine source paths (should never appear) ──"
check_path_absent "apps/engine source"   "apps/engine/src"
check_path_absent "engine prisma schema" "apps/engine/prisma"
check_path_absent "engine dist"          "apps/engine/dist"

echo ""
echo "── Audio processing binaries ──"
check_file_absent "ffmpeg binary"  "ffmpeg"
check_file_absent "ffprobe binary" "ffprobe"

echo ""
echo "── Source maps (reveals source) ──"
check_file_absent "TypeScript source maps" "*.js.map"
check_file_absent ".ts source files"       "*.ts"

echo ""
echo "── Secret / credential leaks ──"
HITS=$(find "$SCRATCH/all" -type f \( -name ".env" -o -name ".env.*" \) 2>/dev/null \
  | grep -vE "\.example$" | head -5 || true)
if [ -n "$HITS" ]; then
  echo "  ✗ Leaked .env files:"
  echo "$HITS" | sed 's|^|    |'
  FAIL=$((FAIL + 1))
else
  echo "  ✓ No .env files"
  PASSES=$((PASSES + 1))
fi

# Hardcoded API key patterns
check_grep "Hardcoded Google API key" "AIza[A-Za-z0-9_-]{30,}"
check_grep "Hardcoded Sarvam-style key" "sk_[a-z0-9]{20,}[^_]*_"
check_grep "Hardcoded Docker token" "dckr_pat_[A-Za-z0-9_-]{20,}"
check_grep "Hardcoded OHM engine key" "ohm_engine_[a-zA-Z0-9-]+_[A-Za-z0-9]{8,}"

echo ""
echo "── Test files (warning only) ──"
HITS=$(find "$SCRATCH/all" -type f \( -name "*.spec.js" -o -name "*.test.js" -o -name "*.spec.ts" \) 2>/dev/null | head -5 || true)
if [ -n "$HITS" ]; then
  echo "  ⚠ Test files shipped (consider .dockerignore):"
  echo "$HITS" | sed 's|^|    |' | head -3
  WARN=$((WARN + 1))
  [ "$STRICT" = true ] && FAIL=$((FAIL + 1))
else
  echo "  ✓ No test files"
  PASSES=$((PASSES + 1))
fi

echo ""
echo "══════════════════════════════════════════════════════════════════"
echo "  PASS: $PASSES   FAIL: $FAIL   WARN: $WARN"
echo "══════════════════════════════════════════════════════════════════"
if [ "$FAIL" -eq 0 ]; then
  if [ "$WARN" -gt 0 ] && [ "$STRICT" = false ]; then
    echo "  ✓ CLEAN with $WARN soft warning(s) — image is safe to ship."
    echo "    Use --strict to fail on warnings."
  else
    echo "  ✓ CLEAN — image is safe to ship to hospitals."
  fi
  exit 0
else
  echo "  ✗ LEAK DETECTED — DO NOT SHIP this image."
  echo ""
  echo "  Common fixes:"
  echo "  - Add the offending path to apps/api/Dockerfile.dockerignore"
  echo "  - Narrow the COPY commands in apps/api/Dockerfile"
  echo "  - Confirm tsconfig.build.json has sourceMap: false"
  echo "  - Remove the vendor SDK from apps/api/package.json"
  exit 1
fi
