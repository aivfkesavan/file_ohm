// Adds a "Copy" button to every <pre><code> block, wrapping it in a .codeblock
// container. Shared by every doc page — single source of truth.
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("pre > code").forEach((code) => {
    const pre = code.parentElement;
    const wrap = document.createElement("div");
    wrap.className = "codeblock";
    pre.parentNode.insertBefore(wrap, pre);
    wrap.appendChild(pre);

    const btn = document.createElement("button");
    btn.className = "copy";
    btn.type = "button";
    btn.textContent = "Copy";
    btn.addEventListener("click", () => {
      navigator.clipboard.writeText(code.textContent).then(() => {
        btn.textContent = "Copied!";
        btn.classList.add("copied");
        setTimeout(() => {
          btn.textContent = "Copy";
          btn.classList.remove("copied");
        }, 1600);
      });
    });
    wrap.appendChild(btn);
  });

  // Highlight current page in sidebar.
  const here = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll("nav.sidebar a").forEach((a) => {
    const href = a.getAttribute("href");
    if (href === here) a.classList.add("active");
  });
});
