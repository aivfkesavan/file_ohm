# OHM Hospital Deployment Pack

Everything a hospital IT team needs to run OHM on-premise.

The hospital deployment is a single Docker Compose stack consisting of:

- React SPAs: doctor (web), admin, coder tools, Studio console, landing, docs
- Hospital API (NestJS orchestrator)
- Postgres (clinical database — all PHI lives here)
- Redis (cache + session)
- MinIO (audio object store)
- Caddy (TLS termination + reverse proxy)

The hospital deployment **does NOT** contain:

- LLM or STT vendor keys
- System prompts or extraction logic
- ffmpeg / audio chunking
- Full LOINC / ICD-10 / SNOMED / drug datasets

All AI work is delegated to `https://api.ohm-engine.in` over HTTPS using
the per-hospital API key OHM Ops gives you. The engine runs on OHM-controlled
hardware and is never delivered to any hospital.

---

## What OHM Ops gives you

A secure handoff with:

1. `OHM_ENGINE_API_KEY` — a string starting with `ohm_engine_<your-slug>_...`. Treat as a secret. Rotate by asking OHM for a new one; old key honored 24h.
2. Private Docker registry credentials (read-only, scoped to your hospital).
3. This deploy pack (`deploy/hospital/`).
4. A signed Data Processing Agreement (DPA) covering audio-in-transit to OHM.

---

## Deployment modes — pick the one that matches your network

| Mode | When to use | Domain / Host | TLS | Compose flag |
|---|---|---|---|---|
| **tls** | Production hospital with public DNS + Let's Encrypt | `kauvery.example` | yes (auto) | `--profile edge` |
| **lan** | Hospital with internal DNS (e.g. `*.ohm.local`) | `ohm.local` | none (or self-signed) | none |
| **ip** | Single server, no DNS at all | `192.168.1.10` | none | none |
| **localhost** | Single-laptop demo / trial | `localhost` | none | none |

All four modes share the same Docker image (`devforallohmok/hospital:vX.Y.Z`)
and same docker-compose.yml. Only the `.env` differs — the `setup.sh`
wizard writes the right one for you.

## Prerequisites

- Linux server (Ubuntu 22.04 LTS or RHEL 9 recommended), 8+ vCPU, 32 GB RAM, 500 GB SSD
- Docker 25+ and Docker Compose v2
- A subdomain you own (e.g. `*.kauvery.example` or any internal domain)
- Outbound HTTPS to `api.ohm-engine.in:443` whitelisted on your firewall
- Inbound HTTPS to `*.<your-hospital>.example` from your LAN

---

## Install — one command

Everything below (Docker login, secrets, .env, runtime config, Caddy,
SMTP, migrations, first admin user, health check) happens in a single
script call. No manual file editing required when you pass the flags.

```bash
# 1. Unpack the bundle
sudo mkdir -p /opt/ohm && cd /opt/ohm
sudo tar -xzf ohm-hospital-vX.Y.Z.tar.gz
cd ohm-hospital
sudo chown -R $USER:$USER .

# 2. ONE command — installs end-to-end
./deploy/hospital/install.sh \
  --mode tls --domain kauvery.example \
  --docker-token dckr_pat_... \
  --engine-key  ohm_engine_<your-slug>_xxxxxxxx \
  --org-name    "Kauvery Hospital" \
  --admin-name  "Dr. Arjun" \
  --admin-email arjun@kauvery.example \
  --admin-password 'Strong-Pass-Here' \
  --smtp-host smtp.sendgrid.net \
  --smtp-user apikey \
  --smtp-pass <sendgrid-api-key> \
  --smtp-from "Kauvery <noreply@kauvery.example>" \
  --acme-email it@kauvery.example
```

The installer runs seven phases and prints a green ✓ for each:

1. **Pre-flight** — checks Docker daemon, compose v2, required tools, disk space, ports in use.
2. **Docker Hub login** — uses `--docker-token`, then sanity-pulls one image to confirm repo access.
3. **Configure** — invokes `./setup.sh` with all flags forwarded; writes `.env` + per-SPA `config.js` + Caddyfile (TLS mode).
4. **Boot** — `docker compose pull && up -d` (auto-applies `--profile edge` for TLS).
5. **Wait for API health** — polls `/api/health` up to 5 min while Prisma `db push` runs on first boot.
6. **Bootstrap admin** — `POST /api/setup/init` to create the first org + admin user (only fires if the DB is empty).
7. **Verify** — full `verify.sh` smoke test; exit code propagates.

Re-running is safe: secrets (Postgres / Redis / MinIO / JWT) persist
across runs. Only the URLs and SMTP fields update.

### Mode shortcuts

| Mode | Use | Flags |
|---|---|---|
| **tls** | Production hospital with public DNS | `--mode tls --domain <name>` |
| **lan** | Hospital internal DNS (`ohm.local`) | `--mode lan --domain <name>` |
| **ip** | Single server, no DNS | `--mode ip --host 192.168.1.10` |
| **localhost** | Demo on a laptop | `--mode localhost` |

### Advanced (run pieces individually)

```bash
./deploy/hospital/setup.sh   --mode tls --domain kauvery.example --engine-key ...   # write .env only
docker compose pull && docker compose --profile edge up -d                          # boot
./deploy/hospital/verify.sh                                                         # health check
```

`./install.sh` is just a thin shell around those — use the long form if
you need to introspect each step.

Expected output of `verify.sh` on success:

```
✓ Hospital API up (port 4000)
✓ Engine reachable (api.ohm-engine.in)
✓ All services healthy.
You're live.
```

---

## After install

If you ran `install.sh` with `--admin-email`, the first admin is
already created. Otherwise create one manually:

```bash
curl -X POST http://localhost:4000/api/setup/init \
  -H 'Content-Type: application/json' \
  -d '{
    "organizationName": "Kauvery Hospital",
    "adminName":        "Dr. Arjun",
    "adminEmail":       "arjun@kauvery.example",
    "adminPassword":    "Strong-Pass-Here"
  }'
```

Then in your browser:

1. Open `https://admin.<your-hospital>.example`
2. Log in as the seeded admin
3. Go to Invitations → invite your doctors
4. They click the email link, set a password, log in at `https://app.<your-hospital>.example`

---

## Upgrades

```bash
cd /opt/ohm/ohm-hospital

# Bump to a new version (atomic — all 7 images move together)
./upgrade.sh v0.13.0

# OR (current RELEASE_VERSION in .env, just pull + restart)
./upgrade.sh

# OR safer — auto-rollback if verify.sh fails after the upgrade
./upgrade.sh v0.13.0 --rollback v0.12.1
```

`upgrade.sh`:
1. Verifies all 7 images for the target version exist on Docker Hub before touching anything (refuses partial releases).
2. Bumps `RELEASE_VERSION=` in `.env`.
3. `docker compose pull` — atomically grabs all 7 images.
4. `docker compose up -d` — restarts only services whose image changed.
5. `prisma db push` — applies any new additive migrations.
6. `verify.sh` — smoke test, including the **same-version invariant** (refuses to call the deploy "healthy" if any service is on a different version).
7. If verify fails and `--rollback <v>` was passed, auto-rolls back.

Same shell as the upgrade — no extra hands-on work.

### Manual upgrade (no script)

```bash
# Edit .env, bump RELEASE_VERSION
$EDITOR .env
docker compose pull
docker compose up -d
docker compose exec api pnpm exec prisma db push --accept-data-loss=false
./verify.sh
```

Schema migrations are forward-only and additive. No data is dropped.

### Rollback

```bash
./upgrade.sh v0.12.0   # previous version — fully reversible
```

The atomic-version contract means you can always roll back to any
previous tagged release in one command. The only thing that doesn't
auto-revert is the database schema (migrations are forward-only).
For destructive schema changes OHM ships in two consecutive releases
so a one-step rollback never loses data.

---

## Day-to-day operations

| Task | Command |
|---|---|
| Tail the API logs | `docker compose logs -f api` |
| Check engine connectivity | `docker compose exec api curl -s https://api.ohm-engine.in/v1/health` |
| Backup the database | `docker compose exec postgres pg_dump -U postgres ohm > backup-$(date +%F).sql` |
| Restore | `cat backup.sql \| docker compose exec -T postgres psql -U postgres -d ohm` |
| Rotate engine key | Update `OHM_ENGINE_API_KEY` in `.env` → `docker compose restart api` |

---

## Troubleshooting

**`Engine unreachable` warnings in the API logs**:
1. From the server, run `curl -I https://api.ohm-engine.in/v1/health` — should return 200.
2. If it times out, check your firewall is allowing outbound HTTPS to that domain.
3. If 401: your `OHM_ENGINE_API_KEY` is wrong, expired, or revoked — contact OHM Ops.
4. The hospital API will keep working for non-AI flows (auth, patient lookup, etc). AI features will show "queued for retry" — they auto-recover when the engine is back.

**`Caddy can't issue certificate`**:
- Caddy needs port 80 reachable from Let's Encrypt for HTTP-01 challenges. If your network blocks port 80 inbound, switch Caddy to DNS-01 (edit `Caddyfile`).

**Doctor app loads but API calls 401**:
- JWT secret mismatch between sessions and current `.env`. Restart: `docker compose restart api`.

---

## Compliance posture

- All PHI (patients, notes, audio files) lives in your Postgres + MinIO. Never leaves the hospital LAN except as **audio bytes** sent to `api.ohm-engine.in` for transcription + extraction.
- The engine processes audio in-memory and returns the structured result. **No audio or transcript is persisted on the engine side.** Engine logs only count metadata (latency, token count, status).
- Your DPA with OHM covers this transit. Engine infrastructure is MeitY-empanelled and India-resident.

---

## Support

- **Engine outage / API key issues**: ohm-ops@ohm.doctor (24/7 PagerDuty)
- **Software bugs**: file at https://github.com/open-holistic-medicine/ohm-issues
- **Onboarding help**: hospital-onboarding@ohm.doctor
