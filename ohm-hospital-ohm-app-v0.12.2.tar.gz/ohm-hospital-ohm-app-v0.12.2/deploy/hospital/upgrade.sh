#!/usr/bin/env bash
#
# Upgrade a hospital deployment to a new RELEASE_VERSION.
#
# Usage
# ─────
#   ./upgrade.sh                                # use current .env RELEASE_VERSION
#   ./upgrade.sh v0.13.0                        # bump .env to v0.13.0
#   ./upgrade.sh v0.13.0 --rollback v0.12.2     # auto-rollback if verify fails
#   ./upgrade.sh v0.13.0 --no-backup            # skip the pre-upgrade backup
#
# What it does, in order:
#   1.  Acquires an exclusive lock so two operators can't upgrade at once.
#   2.  Pre-flight: docker logged in, all 7 target images on Docker Hub.
#   3.  Snapshots Postgres + MinIO via scripts/backup-hospital.sh (unless --no-backup).
#   4.  Bumps RELEASE_VERSION in .env (atomically, preserving chmod 600).
#   5.  docker compose pull --quiet
#   6.  docker compose up -d
#   7.  Waits up to 90s for the api container to report healthy.
#   8.  Applies additive Prisma schema migrations.
#   9.  Runs ./verify.sh.
#   10. If verify fails AND --rollback was passed, rolls back exactly once.

set -Eeuo pipefail

# ─── Locking — only one upgrade at a time ────────────────────────────
LOCKFILE="/tmp/ohm-upgrade.lock"
exec 9>"$LOCKFILE"
if ! flock -n 9; then
  echo "✗ Another upgrade is already running (lock: $LOCKFILE). Wait or:" >&2
  echo "    rm $LOCKFILE      # only if you're sure no other run is in progress" >&2
  exit 1
fi
trap 'rc=$?; rm -f "${ENV_FILE:-}.tmp"; exit $rc' EXIT

cd "$(dirname "${BASH_SOURCE[0]}")"

REPO="${DOCKERHUB_REPO:-devforallohmok/hospital}"
ENV_FILE="${ENV_FILE:-./.env}"

NEW_VERSION=""
ROLLBACK_VERSION=""
DO_BACKUP=true
ROLLED_BACK=false   # internal flag to bound recursion

while [ $# -gt 0 ]; do
  case "$1" in
    --rollback)      ROLLBACK_VERSION="$2"; shift 2 ;;
    --no-backup)     DO_BACKUP=false; shift ;;
    --rolled-back)   ROLLED_BACK=true; shift ;;   # internal
    v[0-9]*.[0-9]*.[0-9]*) NEW_VERSION="$1"; shift ;;
    -h|--help)
      sed -n '2,24p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *) echo "✗ Unknown arg: $1 (run with --help)" >&2; exit 2 ;;
  esac
done

# Validate version format if provided.
if [ -n "$NEW_VERSION" ] && [[ ! "$NEW_VERSION" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "✗ Invalid version '$NEW_VERSION' — expected vX.Y.Z." >&2
  exit 2
fi
if [ -n "$ROLLBACK_VERSION" ] && [[ ! "$ROLLBACK_VERSION" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "✗ Invalid --rollback version '$ROLLBACK_VERSION'." >&2
  exit 2
fi

# ─── Read current RELEASE_VERSION ────────────────────────────────────
if [ ! -f "$ENV_FILE" ]; then
  echo "✗ $ENV_FILE missing. Run setup.sh first." >&2
  exit 1
fi

CUR_VERSION=$(grep -E '^RELEASE_VERSION=' "$ENV_FILE" | head -1 | cut -d= -f2- || true)
NEW_VERSION="${NEW_VERSION:-$CUR_VERSION}"
if [ -z "$NEW_VERSION" ]; then
  echo "✗ No RELEASE_VERSION in $ENV_FILE and no version on command line." >&2
  exit 1
fi

echo ""
echo "══════════════════════════════════════════════════════════════════"
echo "  OHM upgrade"
echo "══════════════════════════════════════════════════════════════════"
echo "  From:           $CUR_VERSION"
echo "  To:             $NEW_VERSION"
echo "  Rollback to:    ${ROLLBACK_VERSION:-(none — manual rollback only)}"
echo "  Pre-backup:     $([ "$DO_BACKUP" = true ] && echo yes || echo no)"
echo ""

# ─── Pre-flight 1: Docker daemon reachable ──────────────────────────
echo "→ Pre-flight: Docker daemon"
if ! docker info >/dev/null 2>&1; then
  echo "  ✗ Cannot reach Docker daemon. Is Docker running?" >&2
  exit 1
fi
echo "  ✓ Docker daemon reachable"

# ─── Pre-flight 2: Docker Hub login ─────────────────────────────────
echo "→ Pre-flight: Docker Hub login"
if ! docker info 2>/dev/null | grep -q "Username:"; then
  echo "  ✗ Not logged in to Docker Hub." >&2
  echo "    Run:  echo \"<token>\" | docker login -u devforallohmok --password-stdin" >&2
  echo "    Get a fresh token from info@ohm.doctor if needed." >&2
  exit 1
fi
echo "  ✓ Logged in"

# ─── Pre-flight 3: all 7 target images exist on Docker Hub ──────────
echo "→ Pre-flight: $NEW_VERSION images on Docker Hub"
MISSING=()
for app in api web admin studio tools landing docs; do
  if ! docker manifest inspect "${REPO}:${app}-${NEW_VERSION}" >/dev/null 2>&1; then
    MISSING+=("${app}-${NEW_VERSION}")
  fi
done
if [ "${#MISSING[@]}" -gt 0 ]; then
  echo "  ✗ Missing $(printf '%s images: ' "${#MISSING[@]}")" >&2
  for m in "${MISSING[@]}"; do echo "      ${REPO}:${m}" >&2; done
  echo "" >&2
  echo "  Either the release pipeline hasn't finished, OR your pull token" >&2
  echo "  doesn't cover this repo. Email info@ohm.doctor." >&2
  exit 1
fi
echo "  ✓ All 7 images present"

# ─── Pre-flight 4: same .env file structure (just sanity) ───────────
for required in DATABASE_URL POSTGRES_PASSWORD OHM_ENGINE_API_KEY; do
  if ! grep -qE "^${required}=" "$ENV_FILE"; then
    echo "  ⚠ $ENV_FILE missing required key '$required'. Run setup.sh first." >&2
    exit 1
  fi
done

# Engine key must be a real key, not the placeholder. Catching this
# here avoids a wasted upgrade cycle that would fail at verify.sh's
# engine-probe stage anyway.
ENGINE_KEY_VAL=$(grep -E '^OHM_ENGINE_API_KEY=' "$ENV_FILE" | cut -d= -f2-)
case "$ENGINE_KEY_VAL" in
  ''|__paste_key_from_ohm_ops_here__|*"<paste"*|*"REPLACE_ME"*)
    echo "  ✗ OHM_ENGINE_API_KEY in $ENV_FILE is still a placeholder." >&2
    echo "    Paste the real key from your OHM Ops handoff and re-run." >&2
    echo "    Help: info@ohm.doctor" >&2
    exit 1
    ;;
esac

# ─── Pre-upgrade backup ─────────────────────────────────────────────
if [ "$DO_BACKUP" = true ]; then
  echo ""
  echo "→ Pre-upgrade backup"
  if [ -x "../../scripts/backup-hospital.sh" ]; then
    if ../../scripts/backup-hospital.sh >/dev/null 2>&1; then
      echo "  ✓ Backup snapshot written"
    else
      echo "  ⚠ Backup script failed — continuing upgrade anyway." >&2
      echo "    Investigate with: ./scripts/backup-hospital.sh" >&2
    fi
  else
    echo "  ⊘ scripts/backup-hospital.sh not found — skipping pre-upgrade snapshot."
  fi
fi

# ─── Update .env (atomic write, preserve mode 600) ──────────────────
if [ "$CUR_VERSION" != "$NEW_VERSION" ]; then
  echo ""
  echo "→ Updating $ENV_FILE: RELEASE_VERSION → $NEW_VERSION"
  if grep -qE '^RELEASE_VERSION=' "$ENV_FILE"; then
    awk -v v="$NEW_VERSION" '/^RELEASE_VERSION=/ {print "RELEASE_VERSION=" v; next} {print}' \
      "$ENV_FILE" > "$ENV_FILE.tmp"
  else
    cat "$ENV_FILE" > "$ENV_FILE.tmp"
    echo "RELEASE_VERSION=$NEW_VERSION" >> "$ENV_FILE.tmp"
  fi
  # Preserve permissions
  chmod --reference="$ENV_FILE" "$ENV_FILE.tmp" 2>/dev/null \
    || chmod 600 "$ENV_FILE.tmp"   # BSD chmod fallback
  mv "$ENV_FILE.tmp" "$ENV_FILE"
fi

# ─── Pull + restart ──────────────────────────────────────────────────
echo ""
echo "→ Pulling images (this can take a couple of minutes)..."
docker compose pull --quiet

echo "→ Restarting services..."
docker compose up -d --remove-orphans

# ─── Wait for api to be healthy before migrating ────────────────────
echo "→ Waiting for api to report healthy (up to 90s)..."
HEALTH_TIMEOUT=90
SLEEP_INTERVAL=3
elapsed=0
while [ $elapsed -lt $HEALTH_TIMEOUT ]; do
  if docker compose exec -T api curl -fsS http://localhost:4000/api/health >/dev/null 2>&1; then
    echo "  ✓ api healthy after ${elapsed}s"
    break
  fi
  sleep $SLEEP_INTERVAL
  elapsed=$((elapsed + SLEEP_INTERVAL))
done
if [ $elapsed -ge $HEALTH_TIMEOUT ]; then
  echo "  ✗ api never reported healthy. Check 'docker compose logs api'." >&2
  echo ""
  if [ -n "$ROLLBACK_VERSION" ] && [ "$ROLLED_BACK" = false ]; then
    echo "→ Auto-rolling back to $ROLLBACK_VERSION..."
    exec "$0" "$ROLLBACK_VERSION" --no-backup --rolled-back
  fi
  echo "  Manual rollback:  ./upgrade.sh $CUR_VERSION --no-backup"
  exit 1
fi

# ─── Schema migrations (additive only) ──────────────────────────────
echo "→ Applying additive DB migrations..."
if ! docker compose exec -T api pnpm exec prisma db push --skip-generate --accept-data-loss=false; then
  echo "" >&2
  echo "✗ Schema migration failed." >&2
  echo "  Check release notes for the target version — destructive changes" >&2
  echo "  may need a two-phase upgrade (see docs/install/reference/upgrade.html)." >&2
  if [ -n "$ROLLBACK_VERSION" ] && [ "$ROLLED_BACK" = false ]; then
    echo "→ Auto-rolling back to $ROLLBACK_VERSION..."
    exec "$0" "$ROLLBACK_VERSION" --no-backup --rolled-back
  fi
  exit 1
fi

# ─── Verify ──────────────────────────────────────────────────────────
echo "→ Running smoke verify..."
if ./verify.sh; then
  echo ""
  echo "══════════════════════════════════════════════════════════════════"
  echo "  ✓ Upgrade to $NEW_VERSION complete."
  echo "══════════════════════════════════════════════════════════════════"
  exit 0
fi

# ─── Verify failed — auto-rollback if possible ──────────────────────
echo ""
echo "✗ Verify failed after upgrade to $NEW_VERSION."

if [ -z "$ROLLBACK_VERSION" ] || [ "$ROLLED_BACK" = true ]; then
  echo ""
  echo "  Manual rollback to a known-good version:"
  echo "    ./upgrade.sh $CUR_VERSION --no-backup"
  exit 1
fi

echo "→ Auto-rolling back to $ROLLBACK_VERSION..."
exec "$0" "$ROLLBACK_VERSION" --no-backup --rolled-back
