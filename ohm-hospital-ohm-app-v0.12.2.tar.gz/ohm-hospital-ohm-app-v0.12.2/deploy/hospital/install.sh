#!/usr/bin/env bash
#
# OHM hospital installer — ONE COMMAND, ZERO MANUAL STEPS.
#
# Runs the full deploy from a clean Docker host to a live, verified stack
# with a bootstrapped admin user. Idempotent — safe to re-run.
#
# What it does (in order)
# ───────────────────────
#   1. Pre-flight  — Docker daemon, compose plugin, required tools,
#                    free disk + ports, optional firewall hint.
#   2. Registry    — docker login (using --docker-token), then test that
#                    one image actually pulls before doing the full pull.
#   3. Wizard      — invokes ./setup.sh with every flag forwarded, so the
#                    .env + per-SPA config.js + Caddyfile (TLS) all land
#                    headlessly. No interactive prompts.
#   4. Pull + boot — docker compose pull && up -d (with --profile edge
#                    auto-applied for TLS mode).
#   5. Wait for /api/health   — polls up to 5 min for the api container
#                                to come healthy (Prisma db-push runs on
#                                first boot inside the container).
#   6. Bootstrap admin — POSTs /api/setup/init to create the first org
#                        + admin user (only if --admin-email is given AND
#                        no org exists yet).
#   7. Verify      — runs verify.sh end-to-end. Exit code propagates.
#
# Minimal headless install
# ────────────────────────
#   ./install.sh \
#     --mode tls \
#     --domain kauvery.example \
#     --docker-token dckr_pat_... \
#     --engine-key  ohm_engine_kauvery_xxx \
#     --org-name    "Kauvery Hospital" \
#     --admin-name  "Dr. Arjun" \
#     --admin-email arjun@kauvery.example \
#     --admin-password "Strong-Pass-Here" \
#     --smtp-host smtp.sendgrid.net \
#     --smtp-user apikey \
#     --smtp-pass <sendgrid-api-key> \
#     --smtp-from "Kauvery <noreply@kauvery.example>"
#
# Flags (all forwarded to setup.sh unless noted)
#   --mode <tls|lan|ip|localhost>      required
#   --domain <name>                    for tls + lan
#   --host <ip-or-hostname>            for ip
#   --engine-key <key>                 required
#   --engine-url <url>                 default https://api.ohm-engine.in
#   --version <vX.Y.Z>                 default v0.12.2
#   --storage-driver <s3|local>        default s3
#   --smtp-host / --smtp-port / --smtp-user / --smtp-pass / --smtp-from
#   --acme-email <addr>                Let's Encrypt notifications (TLS)
#
#   --docker-token <pat>               OHM-issued read-only Docker Hub PAT.
#                                      Skipped if you're already logged in.
#   --docker-user  <user>              default devforallohmok
#   --repo         <user/image>        default devforallohmok/hospital
#
#   --org-name <"Hospital Name">       passed to /api/setup/init
#   --admin-name <"Dr. ___">           passed to /api/setup/init
#   --admin-email <addr>               passed to /api/setup/init
#   --admin-password <pass>            passed to /api/setup/init
#                                      All four together trigger bootstrap;
#                                      omit any to skip the bootstrap step.
#
#   --skip-pull                        don't docker compose pull
#   --skip-verify                      don't run verify.sh at the end
#   --skip-bootstrap                   never POST /api/setup/init
#   --health-timeout <secs>            api healthcheck timeout (default 300)
#   -h | --help                        this message

set -Eeuo pipefail

# Resolve absolute path BEFORE chdir so usage() can read this file later.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
SCRIPT_PATH="$SCRIPT_DIR/$(basename "${BASH_SOURCE[0]}")"
cd "$SCRIPT_DIR"

# ─── Defaults ────────────────────────────────────────────────────────
MODE=""
DOMAIN=""
HOST=""
ENGINE_KEY="${OHM_ENGINE_API_KEY:-}"
ENGINE_URL="${OHM_ENGINE_URL:-https://api.ohm-engine.in}"
RELEASE_VERSION="${RELEASE_VERSION:-v0.12.2}"
STORAGE_DRIVER="s3"

SMTP_HOST_FLAG=""
SMTP_PORT_FLAG=""
SMTP_USER_FLAG=""
SMTP_PASS_FLAG=""
SMTP_FROM_FLAG=""
ACME_EMAIL_FLAG=""

DOCKER_TOKEN=""
DOCKER_USER="${DOCKER_USER:-devforallohmok}"
DOCKERHUB_REPO="${DOCKERHUB_REPO:-devforallohmok/hospital}"

ORG_NAME=""
ADMIN_NAME=""
ADMIN_EMAIL=""
ADMIN_PASSWORD=""

DO_PULL=true
DO_VERIFY=true
DO_BOOTSTRAP=true
HEALTH_TIMEOUT=300

# ─── Helpers ─────────────────────────────────────────────────────────
log_info()    { printf '  → %s\n' "$*"; }
log_ok()      { printf '  \033[32m✓\033[0m %s\n' "$*"; }
log_warn()    { printf '  \033[33m⚠\033[0m %s\n' "$*" >&2; }
log_err()     { printf '\033[31m✗\033[0m %s\n' "$*" >&2; }
log_header()  { printf '\n\033[1m── %s ──\033[0m\n' "$*"; }

bail() { log_err "$*"; exit 1; }

usage() { sed -n '2,70p' "$SCRIPT_PATH" | sed 's/^# \{0,1\}//'; }

# Pick compose subcommand: prefer `docker compose`, fall back to docker-compose.
COMPOSE_CMD=""
detect_compose() {
  if docker compose version >/dev/null 2>&1; then
    COMPOSE_CMD="docker compose"
  elif command -v docker-compose >/dev/null 2>&1; then
    COMPOSE_CMD="docker-compose"
  else
    return 1
  fi
}

# ─── Parse flags ─────────────────────────────────────────────────────
while [ $# -gt 0 ]; do
  case "$1" in
    --mode)             MODE="$2"; shift 2 ;;
    --domain)           DOMAIN="$2"; shift 2 ;;
    --host)             HOST="$2"; shift 2 ;;
    --engine-key)       ENGINE_KEY="$2"; shift 2 ;;
    --engine-url)       ENGINE_URL="$2"; shift 2 ;;
    --version)          RELEASE_VERSION="$2"; shift 2 ;;
    --storage-driver)   STORAGE_DRIVER="$2"; shift 2 ;;
    --smtp-host)        SMTP_HOST_FLAG="$2"; shift 2 ;;
    --smtp-port)        SMTP_PORT_FLAG="$2"; shift 2 ;;
    --smtp-user)        SMTP_USER_FLAG="$2"; shift 2 ;;
    --smtp-pass)        SMTP_PASS_FLAG="$2"; shift 2 ;;
    --smtp-from)        SMTP_FROM_FLAG="$2"; shift 2 ;;
    --acme-email)       ACME_EMAIL_FLAG="$2"; shift 2 ;;
    --docker-token)     DOCKER_TOKEN="$2"; shift 2 ;;
    --docker-user)      DOCKER_USER="$2"; shift 2 ;;
    --repo)             DOCKERHUB_REPO="$2"; shift 2 ;;
    --org-name)         ORG_NAME="$2"; shift 2 ;;
    --admin-name)       ADMIN_NAME="$2"; shift 2 ;;
    --admin-email)      ADMIN_EMAIL="$2"; shift 2 ;;
    --admin-password)   ADMIN_PASSWORD="$2"; shift 2 ;;
    --skip-pull)        DO_PULL=false; shift ;;
    --skip-verify)      DO_VERIFY=false; shift ;;
    --skip-bootstrap)   DO_BOOTSTRAP=false; shift ;;
    --health-timeout)   HEALTH_TIMEOUT="$2"; shift 2 ;;
    -h|--help)          usage; exit 0 ;;
    *) bail "Unknown flag: $1 (run with --help)" ;;
  esac
done

[ -z "$MODE" ] && { usage; echo ""; bail "--mode required."; }

# ─── 1. Pre-flight ───────────────────────────────────────────────────
log_header "1. Pre-flight"

for tool in docker curl openssl awk sed grep; do
  command -v "$tool" >/dev/null 2>&1 || bail "Missing required tool: $tool"
done

if ! docker info >/dev/null 2>&1; then
  bail "Docker daemon is not running. Start it (Docker Desktop, systemctl start docker, etc.) and retry."
fi
log_ok "Docker daemon is up"

if ! detect_compose; then
  bail "Neither 'docker compose' nor 'docker-compose' is available. Install Docker Compose v2 plugin."
fi
log_ok "Compose: $COMPOSE_CMD"

# Disk-space sanity — refuse if <10 GB free in working dir (volumes + images need room).
FREE_KB=$(df -k . 2>/dev/null | awk 'NR==2 {print $4}')
if [ -n "$FREE_KB" ] && [ "$FREE_KB" -lt 10485760 ]; then
  log_warn "Less than 10 GB free in $(pwd) — Docker images may not fit."
  log_warn "  Free up space before continuing (Postgres + MinIO need room too)."
fi
log_ok "Disk space sanity"

# Port-free check. Only checks ports that mode actually binds.
declare -a CHECK_PORTS
case "$MODE" in
  tls)        CHECK_PORTS=(80 443) ;;
  lan|ip|localhost)
              CHECK_PORTS=(4000 8080 3002 8084 8085 8083 3010) ;;
esac
PORT_CONFLICTS=()
for p in "${CHECK_PORTS[@]}"; do
  # netstat / ss / lsof — whichever exists
  if command -v ss >/dev/null 2>&1; then
    ss -tln 2>/dev/null | awk '{print $4}' | grep -qE "[:.]${p}\$" && PORT_CONFLICTS+=("$p")
  elif command -v lsof >/dev/null 2>&1; then
    lsof -i ":$p" -sTCP:LISTEN -P -n 2>/dev/null | grep -q LISTEN && PORT_CONFLICTS+=("$p")
  fi
done
if [ "${#PORT_CONFLICTS[@]}" -gt 0 ]; then
  log_warn "Port(s) already in use: ${PORT_CONFLICTS[*]}"
  log_warn "  Stop the conflicting service(s) before proceeding, or compose will fail to bind."
else
  log_ok "Required ports are free"
fi

# ─── 2. Docker registry login ────────────────────────────────────────
log_header "2. Docker Hub login"

LOGGED_IN=false
if docker info 2>/dev/null | grep -q "Username:"; then
  LOGGED_IN=true
fi

if [ "$LOGGED_IN" = false ]; then
  if [ -z "$DOCKER_TOKEN" ]; then
    bail "Not logged in to Docker Hub and no --docker-token given. Get a pull token from info@ohm.doctor."
  fi
  echo "$DOCKER_TOKEN" | docker login -u "$DOCKER_USER" --password-stdin >/dev/null \
    || bail "docker login failed for user '$DOCKER_USER'. Check the token."
  log_ok "Logged in as $DOCKER_USER"
else
  log_ok "Already logged in"
fi

# Sanity-pull one image so we fail fast if the token can't see the repo.
log_info "Probing repo access (pulling ${DOCKERHUB_REPO}:api-${RELEASE_VERSION}) …"
if ! docker pull "${DOCKERHUB_REPO}:api-${RELEASE_VERSION}" >/dev/null 2>&1; then
  bail "Cannot pull ${DOCKERHUB_REPO}:api-${RELEASE_VERSION}. Either the version doesn't exist or the token lacks access. Email info@ohm.doctor."
fi
log_ok "Repo access confirmed"

# ─── 3. Wizard (setup.sh) ────────────────────────────────────────────
log_header "3. Configure (.env + runtime config + Caddyfile)"

SETUP_ARGS=(--mode "$MODE")
[ -n "$DOMAIN" ]       && SETUP_ARGS+=(--domain "$DOMAIN")
[ -n "$HOST" ]         && SETUP_ARGS+=(--host "$HOST")
[ -n "$ENGINE_KEY" ]   && SETUP_ARGS+=(--engine-key "$ENGINE_KEY")
SETUP_ARGS+=(--engine-url "$ENGINE_URL")
SETUP_ARGS+=(--version "$RELEASE_VERSION")
SETUP_ARGS+=(--storage-driver "$STORAGE_DRIVER")
[ -n "$SMTP_HOST_FLAG" ] && SETUP_ARGS+=(--smtp-host "$SMTP_HOST_FLAG")
[ -n "$SMTP_PORT_FLAG" ] && SETUP_ARGS+=(--smtp-port "$SMTP_PORT_FLAG")
[ -n "$SMTP_USER_FLAG" ] && SETUP_ARGS+=(--smtp-user "$SMTP_USER_FLAG")
[ -n "$SMTP_PASS_FLAG" ] && SETUP_ARGS+=(--smtp-pass "$SMTP_PASS_FLAG")
[ -n "$SMTP_FROM_FLAG" ] && SETUP_ARGS+=(--smtp-from "$SMTP_FROM_FLAG")
[ -n "$ACME_EMAIL_FLAG" ] && SETUP_ARGS+=(--acme-email "$ACME_EMAIL_FLAG")

./setup.sh "${SETUP_ARGS[@]}"

# ─── 4. Pull images + boot ───────────────────────────────────────────
log_header "4. Boot the stack"

# Use --env-file to be explicit, since some compose versions don't auto-load
# ./.env when invoked from a different cwd.
COMPOSE_PROFILE_ARGS=()
[ "$MODE" = "tls" ] && COMPOSE_PROFILE_ARGS=(--profile edge)

if [ "$DO_PULL" = true ]; then
  log_info "Pulling images …"
  $COMPOSE_CMD --env-file ./.env "${COMPOSE_PROFILE_ARGS[@]}" pull
  log_ok "Pulled $RELEASE_VERSION across all services"
fi

log_info "Booting (docker compose up -d) …"
$COMPOSE_CMD --env-file ./.env "${COMPOSE_PROFILE_ARGS[@]}" up -d
log_ok "Stack started"

# ─── 5. Wait for api health ──────────────────────────────────────────
log_header "5. Wait for hospital API"

# Migrations run inside the api container on boot (Prisma db push). For
# a fresh deploy that's normally <30 s. We give it up to HEALTH_TIMEOUT.
deadline=$(( $(date +%s) + HEALTH_TIMEOUT ))
last_err=""
log_info "Polling http://localhost:4000/api/health (timeout ${HEALTH_TIMEOUT}s) …"
while true; do
  if RESP=$(curl -fsS --max-time 5 http://localhost:4000/api/health 2>&1); then
    log_ok "API healthy: $RESP"
    break
  fi
  last_err="$RESP"
  now=$(date +%s)
  if [ "$now" -ge "$deadline" ]; then
    log_err "API didn't come healthy within ${HEALTH_TIMEOUT}s."
    log_err "  Last curl output: $last_err"
    log_err "  Tail logs with:  $COMPOSE_CMD logs --tail=80 api"
    exit 1
  fi
  sleep 3
done

# ─── 6. Bootstrap first admin (optional) ─────────────────────────────
if [ "$DO_BOOTSTRAP" = true ] && [ -n "$ADMIN_EMAIL" ]; then
  log_header "6. Bootstrap admin user"

  if [ -z "$ORG_NAME" ] || [ -z "$ADMIN_NAME" ] || [ -z "$ADMIN_PASSWORD" ]; then
    log_warn "--admin-email given but --org-name / --admin-name / --admin-password missing. Skipping bootstrap."
  else
    STATUS=$(curl -fsS http://localhost:4000/api/setup/status 2>/dev/null || echo "")
    if echo "$STATUS" | grep -q '"needsSetup":true'; then
      # Use python (always present on prod servers) to JSON-escape strings safely.
      JSON_PAYLOAD=$(python3 - <<PY
import json
print(json.dumps({
  "organizationName": "$ORG_NAME",
  "adminEmail":      "$ADMIN_EMAIL",
  "adminName":       "$ADMIN_NAME",
  "adminPassword":   "$ADMIN_PASSWORD",
}))
PY
)
      if curl -fsS -X POST http://localhost:4000/api/setup/init \
        -H "Content-Type: application/json" \
        -d "$JSON_PAYLOAD" >/dev/null 2>&1; then
        log_ok "First org + admin created — log in as $ADMIN_EMAIL"
      else
        log_warn "Bootstrap POST failed — you can complete setup via the web UI later."
      fi
    else
      log_ok "Setup already complete (skipping bootstrap)"
    fi
  fi
else
  log_info "Skipping bootstrap (no --admin-email given, or --skip-bootstrap)"
fi

# ─── 7. verify.sh ────────────────────────────────────────────────────
if [ "$DO_VERIFY" = true ]; then
  log_header "7. Verify"
  ./verify.sh || {
    rc=$?
    log_warn "verify.sh exited with code $rc — investigate before going live."
    exit "$rc"
  }
fi

# ─── Done ────────────────────────────────────────────────────────────
echo ""
echo "══════════════════════════════════════════════════════════════════"
echo "  ✓ OHM is installed and running."
echo "══════════════════════════════════════════════════════════════════"
echo ""

# Source the .env to print the resolved URLs without re-deriving them.
# shellcheck disable=SC1091
set -a; . ./.env; set +a

cat <<EOF
  Doctor app:  ${FRONTEND_URL:-http://localhost:8080}
  Admin:       ${ADMIN_URL:-http://localhost:3002}
  Studio:      ${STUDIO_URL:-http://localhost:8084}
  Tools:       ${TOOLS_URL:-http://localhost:8085}
  Landing:     ${LANDING_URL:-http://localhost:8083}
  Docs:        ${DOCS_URL:-http://localhost:3010}

  Next:
    1. Log in as $ADMIN_EMAIL (if bootstrap ran) and invite doctors.
    2. Configure DNS records (TLS mode) so subdomains resolve here.
    3. Run ./verify.sh anytime to re-check health.
    4. Run ../../scripts/backup-hospital.sh nightly via cron.

  Help: info@ohm.doctor
EOF
