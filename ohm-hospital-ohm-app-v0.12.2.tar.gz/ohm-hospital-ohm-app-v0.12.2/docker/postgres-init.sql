-- Postgres init script — mounted into /docker-entrypoint-initdb.d/
-- on the bundled Postgres container. Postgres runs every .sql under
-- that directory ONCE, on first boot of an empty data volume.
--
-- Creates the auxiliary `engine` database alongside the primary `ohm`
-- (which POSTGRES_DB already creates). The engine container then runs
-- `prisma db push` against ENGINE_DATABASE_URL on its first start to
-- populate the schema.
--
-- Hospital deployments don't need this — they don't run the engine
-- locally. Compose still mounts the script (idempotent CREATE DATABASE
-- IF NOT EXISTS pattern), it just isn't exercised.

SELECT 'CREATE DATABASE engine'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'engine')\gexec

-- Grant the bootstrap superuser everything on the new DB (the engine
-- container connects with the same credentials).
GRANT ALL PRIVILEGES ON DATABASE engine TO postgres;
