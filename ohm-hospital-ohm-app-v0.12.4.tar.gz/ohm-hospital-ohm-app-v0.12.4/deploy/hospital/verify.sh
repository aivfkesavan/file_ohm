#!/usr/bin/env bash
#
# Comprehensive post-install / post-upgrade health check for OHM.
# Runs 8 separate checks and exits non-zero on any failure.
#
# Exit codes
#   0  — all checks pass
#   1  — api unreachable
#   2  — engine unreachable
#   3  — infrastructure (Postgres / Redis / MinIO) unhealthy
#   4  — atomic-version invariant violated (mixed versions)
#   5  — one or more SPAs not serving correctly
#   6  — runtime config (per-SPA config.js) missing or wrong
#
# Usage
#   ./verify.sh              # full health check
#   ./verify.sh --quick      # skip the SPA HTTP probes (faster)

set -Eeuo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"

QUICK=false
for arg in "$@"; do
  case "$arg" in
    --quick) QUICK=true ;;
    -h|--help) sed -n '2,17p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown arg: $arg" >&2; exit 2 ;;
  esac
done

API_URL="http://localhost:4000"
REPO="${DOCKERHUB_REPO:-devforallohmok/hospital}"

# Track per-check pass/fail without short-circuiting so the operator
# sees every problem in one run. Separate flags per failure class so
# the final exit code reports the most diagnostic single cause.
FAIL=0
FAIL_ENGINE=0
FAIL_INFRA=0
FAIL_VERSIONS=0
FAIL_CONFIG=0
FAIL_SPA=0
record_fail() { FAIL=$((FAIL + 1)); }

# ─── 1. Hospital API health ──────────────────────────────────────────
echo "→ 1. Hospital API health"
if ! curl -sf "${API_URL}/api/health" >/dev/null 2>&1; then
  echo "  ✗ ${API_URL}/api/health unreachable." >&2
  echo "    Run: docker compose logs --tail=50 api" >&2
  exit 1
fi
HEALTH=$(curl -s "${API_URL}/api/health")
echo "  ✓ up"

# ─── 2. Engine connectivity (proxied via API) ───────────────────────
echo "→ 2. Engine connectivity (via API health endpoint)"
if echo "$HEALTH" | grep -q '"engine":true'; then
  echo "  ✓ engine reachable"
elif echo "$HEALTH" | grep -q '"engine"'; then
  echo "  ✗ engine field present but not true:" >&2
  echo "    $HEALTH" >&2
  FAIL_ENGINE=1
  record_fail
else
  echo "  ⚠ no engine field in health response — older API build?"
fi

# ─── 3. Direct engine probe (from inside the api container) ─────────
echo "→ 3. Direct engine probe from api container"
ENGINE_URL=$(docker compose exec -T api printenv OHM_ENGINE_URL 2>/dev/null | tr -d '\r' || echo "")
if [ -n "$ENGINE_URL" ]; then
  if docker compose exec -T api curl -fsS --max-time 10 "${ENGINE_URL}/v1/health" >/dev/null 2>&1; then
    echo "  ✓ ${ENGINE_URL}/v1/health responding (from inside container)"
  else
    echo "  ✗ api container cannot reach ${ENGINE_URL}/v1/health" >&2
    echo "    Likely cause: hospital firewall blocking outbound HTTPS to that domain." >&2
    echo "    Confirm with: docker compose exec api curl -v ${ENGINE_URL}/v1/health" >&2
    FAIL_ENGINE=1
    record_fail
  fi
else
  echo "  ⚠ OHM_ENGINE_URL not set in container — running disconnected?"
fi

# ─── 4. Infrastructure: Postgres / Redis / MinIO ────────────────────
echo "→ 4. Infrastructure containers"

# Postgres
if docker compose exec -T postgres pg_isready -U postgres -d ohm -q >/dev/null 2>&1; then
  echo "  ✓ postgres ready"
else
  echo "  ✗ postgres not ready. Check: docker compose logs postgres" >&2
  FAIL_INFRA=1
  record_fail
fi

# Redis
if docker compose exec -T redis redis-cli ping >/dev/null 2>&1; then
  echo "  ✓ redis ping ok"
else
  # With password
  REDIS_PW=$(grep -E '^REDIS_PASSWORD=' .env 2>/dev/null | cut -d= -f2- || echo "")
  if [ -n "$REDIS_PW" ] && docker compose exec -T redis redis-cli -a "$REDIS_PW" --no-auth-warning ping >/dev/null 2>&1; then
    echo "  ✓ redis ping ok (auth)"
  else
    echo "  ✗ redis not responding. Check: docker compose logs redis" >&2
    FAIL_INFRA=1
    record_fail
  fi
fi

# MinIO (only if STORAGE_DRIVER=s3)
STORAGE_DRIVER=$(grep -E '^STORAGE_DRIVER=' .env 2>/dev/null | cut -d= -f2- || echo "local")
if [ "$STORAGE_DRIVER" = "s3" ]; then
  if docker compose exec -T minio curl -fsS http://localhost:9000/minio/health/live >/dev/null 2>&1; then
    echo "  ✓ minio live"
  else
    echo "  ✗ minio not responding. Check: docker compose logs minio" >&2
    FAIL_INFRA=1
    record_fail
  fi
else
  echo "  ⊘ minio skipped (STORAGE_DRIVER=$STORAGE_DRIVER)"
fi

# ─── 5. Container states — anything unhealthy? ──────────────────────
echo "→ 5. Container states"
UNHEALTHY=$(docker compose ps --format '{{.Service}} {{.Status}}' 2>/dev/null \
  | awk '$2 != "running" && $2 != "" && $0 !~ /Up.*\(healthy\)/ && $0 !~ /Up [0-9]/ && $0 !~ /^minio-init/ {print}')
if [ -z "$UNHEALTHY" ]; then
  RUNNING_COUNT=$(docker compose ps --format '{{.Service}}' 2>/dev/null | wc -l | tr -d ' ')
  echo "  ✓ all $RUNNING_COUNT containers running"
else
  echo "  ⚠ Some containers are not in 'running' state:"
  echo "$UNHEALTHY" | sed 's/^/      /'
fi

# ─── 6. Atomic version invariant — every container on same tag ──────
echo "→ 6. Atomic version invariant"
declare -a VERSIONS
for svc in api web admin studio tools landing docs; do
  CID=$(docker compose ps -q "$svc" 2>/dev/null || true)
  if [ -z "$CID" ]; then
    echo "  ⚠ $svc not running, skipping"
    continue
  fi
  STATE=$(docker inspect --format '{{.State.Status}}' "$CID" 2>/dev/null || echo "unknown")
  if [ "$STATE" != "running" ]; then
    echo "  ✗ $svc state=$STATE (not running)" >&2
    FAIL_VERSIONS=1
    record_fail
    continue
  fi
  IMG=$(docker inspect --format '{{.Config.Image}}' "$CID" 2>/dev/null || true)
  V=$(echo "$IMG" | sed -nE "s|.*:${svc}-(.+)$|\1|p")
  if [ -z "$V" ]; then
    echo "  ⚠ $svc image '$IMG' doesn't match the expected pattern — skip"
    continue
  fi
  VERSIONS+=("$svc=$V")
done

if [ "${#VERSIONS[@]}" -eq 0 ]; then
  echo "  ⚠ no services running"
elif [ "${#VERSIONS[@]}" -lt 7 ]; then
  # Partial stack — invariant is moot when half the services aren't up.
  # The earlier per-service "not running" record_fail already accounts.
  echo "  ⚠ only ${#VERSIONS[@]}/7 services running — invariant skipped (fix infra first)"
else
  UNIQ=$(printf '%s\n' "${VERSIONS[@]}" | cut -d= -f2 | sort -u | wc -l | tr -d ' ')
  if [ "$UNIQ" = "1" ]; then
    V=$(printf '%s' "${VERSIONS[0]}" | cut -d= -f2)
    echo "  ✓ all ${#VERSIONS[@]} services on $V"
  else
    echo "  ✗ MIXED VERSIONS — partial upgrade detected:" >&2
    for v in "${VERSIONS[@]}"; do echo "      $v" >&2; done
    echo "" >&2
    echo "  Fix: ./upgrade.sh <target-version> --no-backup" >&2
    FAIL_VERSIONS=1
    record_fail
  fi
fi

# ─── 7. Runtime config (per-SPA config.js) ───────────────────────────
echo "→ 7. Runtime config mounted in each SPA"
for svc in web admin studio tools landing; do
  CID=$(docker compose ps -q "$svc" 2>/dev/null || true)
  [ -z "$CID" ] && { echo "  ⊘ $svc not running, skip"; continue; }
  if ! docker compose exec -T "$svc" test -f /usr/share/nginx/html/config.js 2>/dev/null; then
    echo "  ✗ $svc: /config.js missing — runtime config not mounted" >&2
    FAIL_CONFIG=1
    record_fail
    continue
  fi
  if docker compose exec -T "$svc" cat /usr/share/nginx/html/config.js 2>/dev/null \
       | grep -q "apiBaseUrl"; then
    echo "  ✓ $svc config.js present"
  else
    echo "  ⚠ $svc config.js present but has no apiBaseUrl (will fall back to baked default)"
  fi
done

# ─── 8. SPA HTTP reachability (optional, slower) ────────────────────
if [ "$QUICK" = false ]; then
  echo "→ 8. SPA HTTP responses"
  declare -A SPA_PORTS=([web]=8080 [admin]=3002 [studio]=8084 [tools]=8085 [landing]=8083 [docs]=3010)
  for svc in "${!SPA_PORTS[@]}"; do
    PORT="${SPA_PORTS[$svc]}"
    if curl -fsS --max-time 5 "http://localhost:${PORT}/" >/dev/null 2>&1; then
      echo "  ✓ $svc :$PORT serving"
    else
      # Try /healthz too (configured on most SPA nginxes)
      if curl -fsS --max-time 5 "http://localhost:${PORT}/healthz" >/dev/null 2>&1; then
        echo "  ✓ $svc :$PORT serving (/healthz)"
      else
        echo "  ✗ $svc :$PORT not responding to HTTP" >&2
        FAIL_SPA=1
        record_fail
      fi
    fi
  done
fi

# ─── 9. Public-domain reachability (TLS mode only) — WARN-ONLY ──────
# The localhost:* probes above confirm the containers are healthy on
# the host network. This check additionally probes the PUBLIC domain
# to surface DNS / ACME / Caddy issues that the local probes can't see.
#
# DELIBERATELY warn-only (does not call record_fail): a public-DNS
# misconfiguration is outside the upgrade's scope, and upgrade.sh
# auto-rolls back on a non-zero verify exit — we don't want a DNS
# typo to undo a successful container upgrade. Operators read the
# ⚠ output and fix DNS as a separate task.
MODE=$(grep -E '^OHM_MODE=' .env 2>/dev/null | cut -d= -f2- || echo "")
FRONTEND_URL=$(grep -E '^FRONTEND_URL=' .env 2>/dev/null | cut -d= -f2- || echo "")
PUBLIC_API_URL=$(grep -E '^OHM_API_URL=' .env 2>/dev/null | cut -d= -f2- || echo "")
# Fallback for stacks generated by older setup.sh that didn't write OHM_API_URL
if [ -z "$PUBLIC_API_URL" ]; then
  PUBLIC_API_URL=$(grep -E '^VITE_API_BASE_URL=' .env 2>/dev/null | cut -d= -f2- || echo "")
fi
if [ "$MODE" = "tls" ] && [ "$QUICK" = false ]; then
  echo "→ 9. Public domain reachability (TLS / Caddy / ACME) — warn-only"
  if [ -n "$PUBLIC_API_URL" ]; then
    if curl -fsS --max-time 10 "${PUBLIC_API_URL}/api/health" >/dev/null 2>&1; then
      echo "  ✓ ${PUBLIC_API_URL}/api/health responding over public TLS"
    else
      echo "  ⚠ ${PUBLIC_API_URL}/api/health not reachable from this host." >&2
      echo "    Possible causes: DNS A record missing, ACME cert not issued," >&2
      echo "    Caddy upstream wrong, or port 443 blocked. Check:" >&2
      echo "      dig +short ${PUBLIC_API_URL#https://}" >&2
      echo "      docker compose logs --tail=80 caddy" >&2
    fi
  fi
  if [ -n "$FRONTEND_URL" ]; then
    if curl -fsS --max-time 10 "${FRONTEND_URL}/" >/dev/null 2>&1; then
      echo "  ✓ ${FRONTEND_URL}/ responding over public TLS"
    else
      echo "  ⚠ ${FRONTEND_URL}/ not reachable from this host." >&2
      echo "    Same DNS / ACME / Caddy diagnostics apply." >&2
    fi
  fi
fi

echo ""
if [ "$FAIL" -gt 0 ]; then
  echo "══════════════════════════════════════════════════════════════════"
  echo "  ✗ $FAIL check(s) failed. Investigate before going live."
  echo "══════════════════════════════════════════════════════════════════"
  echo ""
  echo "  Full troubleshooting matrix:  docs/install/reference/troubleshoot.html"
  echo "  Help:                         info@ohm.doctor"
  # Exit with the most-diagnostic single cause. Priority: engine (2),
  # infra (3), versions (4), config (6), SPA-only (5). This mirrors
  # the table in the header comment so an operator reading just the
  # exit code knows which class of failure to investigate first.
  if   [ "$FAIL_ENGINE"   = 1 ]; then exit 2
  elif [ "$FAIL_INFRA"    = 1 ]; then exit 3
  elif [ "$FAIL_VERSIONS" = 1 ]; then exit 4
  elif [ "$FAIL_CONFIG"   = 1 ]; then exit 6
  else                                exit 5
  fi
fi

echo "══════════════════════════════════════════════════════════════════"
echo "  ✓ All checks passed. You're live."
echo "══════════════════════════════════════════════════════════════════"
