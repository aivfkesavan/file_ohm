# OHM hospital handoff — ohm-app

Welcome. This bundle has everything you need to deploy OHM at your
hospital. Start with the visual guide:

    open docs/install/index.html

…and follow Track A (Hospital + remote engine) page-by-page.

## What's in this bundle

| What                              | Where                                                  |
|-----------------------------------|--------------------------------------------------------|
| Visual deploy guide (start here)  | `docs/install/index.html` (open in any browser)        |
| **One-shot installer**            | **`deploy/hospital/install.sh` — the easiest path**    |
| Wizard (advanced — runs alone)    | `deploy/hospital/setup.sh`                             |
| Upgrade tool                      | `deploy/hospital/upgrade.sh`                           |
| Smoke test                        | `deploy/hospital/verify.sh`                            |
| Daily backup                      | `scripts/backup-hospital.sh` (cron suggested in docs)  |
| Compose file                      | `docker-compose.yml`                                   |
| Hospital deploy README            | `deploy/hospital/README.md`                            |

## What you still need from OHM (separately, by email)

| What                              | Why                                                |
|-----------------------------------|----------------------------------------------------|
| Docker Hub pull token             | To run `docker compose pull`                       |
| (Engine API key — pre-filled below) | Already in this bundle                           |

> Single contact for everything: **info@ohm.doctor**.

## Your engine API key (pre-filled in this bundle)

```
OHM_ENGINE_API_KEY=ohm_engine_ohm-app_GU34ELYC1giZcBX-mUmvnMjZ_Dq7BZAQ
OHM_ENGINE_URL=https://api.engine.ohm.doctor
```

> Already pre-filled if you use `./deploy/hospital/setup.sh`. If you
> ever need to pass it manually:
> `./setup.sh --engine-key ohm_engine_ohm-app_GU34ELYC1giZcBX-mUmvnMjZ_Dq7BZAQ --engine-url https://api.engine.ohm.doctor …`

## Quick start — ONE command

```bash
cd /opt/ohm

./deploy/hospital/install.sh \
    --mode tls --domain <your-domain.example> \
    --docker-token <docker-hub-pull-token> \
    --engine-key  ohm_engine_ohm-app_GU34ELYC1giZcBX-mUmvnMjZ_Dq7BZAQ \
    --engine-url  https://api.engine.ohm.doctor \
    --org-name    "<Your Hospital Name>" \
    --admin-name  "<Dr. ___>" \
    --admin-email <admin@your-domain.example> \
    --admin-password '<strong-pass>' \
    --smtp-host smtp.sendgrid.net \
    --smtp-user apikey \
    --smtp-pass <sendgrid-api-key> \
    --smtp-from "<Hospital> <noreply@your-domain.example>" \
    --acme-email it@your-domain.example
```

That single call: pre-flights the host, logs into Docker Hub, writes
the .env + per-SPA config.js + Caddyfile, pulls all 7 images, boots
the stack (Prisma db-push runs on first boot inside the container),
waits for the API to come healthy, creates the first admin user, and
finally runs the full verify.sh smoke test.

For LAN / IP / localhost modes, swap `--mode tls --domain …` for
`--mode lan --domain …` / `--mode ip --host …` / `--mode localhost`.

See `docs/install/index.html` for the visual walk-through.

## Day-2 operations

| Task            | Command                                            |
|-----------------|----------------------------------------------------|
| Upgrade         | `./deploy/hospital/upgrade.sh v0.13.0`             |
| Rollback        | `./deploy/hospital/upgrade.sh v0.12.0 --no-backup` |
| Backup (manual) | `./scripts/backup-hospital.sh`                     |
| Health check    | `./deploy/hospital/verify.sh`                      |

Set up the daily backup cron (see `docs/install/reference/backup.html`).

## Support

| Need                                        | Where                                  |
|---------------------------------------------|----------------------------------------|
| Anything OHM-related (keys, bundles, help)  | <info@ohm.doctor>                      |
| Urgent production outage                    | <info@ohm.doctor> with `URGENT` in subj |
| Security vulnerability                      | <security@ohm.doctor>                  |
| Engine uptime status                        | <https://status.ohm-engine.in>         |

Version pinned in this bundle: **v0.12.4**
