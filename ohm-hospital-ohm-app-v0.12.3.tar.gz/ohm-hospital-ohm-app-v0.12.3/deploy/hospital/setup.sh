#!/usr/bin/env bash
#
# OHM hospital deployment wizard.
#
# Writes a complete .env + per-SPA runtime config + (TLS mode) Caddyfile
# for any of four network topologies. Idempotent — re-running preserves
# all generated secrets and only refreshes URLs.
#
# Usage
# ─────
#   ./setup.sh --mode tls       --domain kauvery.example     --engine-key ohm_engine_<slug>_xxx
#   ./setup.sh --mode lan       --domain ohm.local           --engine-key ohm_engine_<slug>_xxx
#   ./setup.sh --mode ip        --host 192.168.1.10          --engine-key ohm_engine_<slug>_xxx
#   ./setup.sh --mode localhost                              --engine-key ohm_engine_<slug>_xxx
#
# Flags
#   --mode <tls|lan|ip|localhost>   required
#   --domain <name>                 required for tls + lan modes
#   --host <ip-or-hostname>         required for ip mode
#   --engine-key <key>              required (or via OHM_ENGINE_API_KEY env var)
#   --engine-url <url>              override engine URL (default: https://api.engine.ohm.doctor)
#   --version <vX.Y.Z>              pin a specific release (default: v0.12.2)
#   --storage-driver <s3|local>     default s3 (bundled MinIO). 'local' uses multer disk.
#   --out <path>                    .env destination (default: ./.env)
#   --dry-run                       preview without writing
#   --smtp-host <host>              SMTP relay (e.g. smtp.sendgrid.net)
#   --smtp-port <n>                 SMTP port (default 587)
#   --smtp-user <user>              SMTP auth user
#   --smtp-pass <pass>              SMTP auth password (app password recommended)
#   --smtp-from <"Name <addr>">     From header on outbound mail
#   --acme-email <addr>             Let's Encrypt notifications (TLS mode only)
#   -h | --help                     this message
#
# What gets auto-generated once (preserved across reruns):
#   POSTGRES_PASSWORD, REDIS_PASSWORD, MINIO_ROOT_PASSWORD, JWT_SECRET,
#   STUDIO_API_KEY_PEPPER  — strong random values.
#
# What you still set manually after running setup.sh:
#   SMTP_HOST / SMTP_USER / SMTP_PASS / SMTP_FROM   — invite & reset emails
#   ALERT_RECIPIENTS                                — on-call escalation
#   CADDY_ACME_EMAIL (TLS mode)                     — Let's Encrypt notifications

set -Eeuo pipefail

# ─── Trap unexpected exits so we never leave half-written tmp files ──
SCRIPT_NAME="$(basename "${BASH_SOURCE[0]}")"
cleanup_on_error() {
  local rc=$?
  if [ -n "${OUT:-}" ] && [ -f "${OUT:-}.tmp" ]; then
    rm -f "${OUT}.tmp"
  fi
  if [ $rc -ne 0 ]; then
    echo "" >&2
    echo "✗ $SCRIPT_NAME exited with code $rc — no .env was written." >&2
  fi
  exit $rc
}
trap cleanup_on_error EXIT

# ─── Defaults ────────────────────────────────────────────────────────
MODE=""
DOMAIN=""
HOST=""
ENGINE_KEY="${OHM_ENGINE_API_KEY:-}"
ENGINE_URL="${OHM_ENGINE_URL:-https://api.engine.ohm.doctor}"
RELEASE_VERSION="${RELEASE_VERSION:-v0.12.3}"
STORAGE_DRIVER="s3"
OUT="${OUT:-./.env}"
DRY_RUN=false
# SMTP flags — optional. If passed, override anything already in .env.
SMTP_HOST_FLAG=""
SMTP_PORT_FLAG=""
SMTP_USER_FLAG=""
SMTP_PASS_FLAG=""
SMTP_FROM_FLAG=""
ACME_EMAIL_FLAG=""

# Default service ports — MUST match docker-compose.yml. Changing here
# without updating compose breaks every wizard-driven deployment.
API_PORT=4000      # api    service
WEB_PORT=8080      # web    service (doctor app)
LANDING_PORT=8083  # landing service
STUDIO_PORT=8084   # studio service
TOOLS_PORT=8085    # tools  service
ADMIN_PORT=3002    # admin  service
DOCS_PORT=3010     # docs   service (Next.js)

# ─── Helpers ─────────────────────────────────────────────────────────
log_info() { printf '  → %s\n' "$*"; }
log_ok()   { printf '  ✓ %s\n' "$*"; }
log_warn() { printf '  ⚠ %s\n' "$*" >&2; }
log_err()  { printf '✗ %s\n' "$*" >&2; }

usage() {
  # Print the comment block at the top of this script (lines 2-30).
  sed -n '2,30p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
}

# Domain validation — RFC-1035-ish hostname (labels separated by dots).
# Each label: alphanumeric + hyphens, 1-63 chars, no leading/trailing hyphen.
is_valid_domain() {
  local d="$1"
  [[ "$d" =~ ^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$ ]]
}

# Host validation — IPv4 OR hostname. (IPv6 not currently supported because
# the URL builder doesn't bracket the literal; flag for future work.)
is_valid_host() {
  local h="$1"
  # IPv4
  [[ "$h" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] && return 0
  # Hostname (allows single-label like 'kauvery-server')
  [[ "$h" =~ ^[a-zA-Z0-9]([a-zA-Z0-9.-]{0,253}[a-zA-Z0-9])?$ ]]
}

# Engine key sanity. Real keys: ohm_engine_<slug>_<random>. Reject placeholders.
is_valid_engine_key() {
  local k="$1"
  [ -n "$k" ] || return 1
  [[ "$k" != *"__"* ]] || return 1
  [[ "$k" != *"<"* ]] || return 1
  [[ "$k" != *"xxx"* ]] || return 1
  return 0
}

gen_secret_b64() { openssl rand -base64 "${1:-32}" | tr -d '\n' | tr '+/' '-_'; }
gen_secret_hex() { openssl rand -hex "${1:-24}"; }

# Read existing value from current .env (if any). Used to preserve secrets.
# Returns empty + exit 0 on miss (pipefail-safe — grep returning 1 must
# not bubble up).
read_existing() {
  [ -f "$OUT" ] || return 0
  local val
  val=$(grep -E "^${1}=" "$OUT" 2>/dev/null | head -1 | cut -d= -f2- || true)
  printf '%s' "$val"
}

# ─── Parse flags ─────────────────────────────────────────────────────
while [ $# -gt 0 ]; do
  case "$1" in
    --mode)             MODE="$2"; shift 2 ;;
    --domain)           DOMAIN="$2"; shift 2 ;;
    --host)             HOST="$2"; shift 2 ;;
    --engine-key)       ENGINE_KEY="$2"; shift 2 ;;
    --engine-url)       ENGINE_URL="$2"; shift 2 ;;
    --version)          RELEASE_VERSION="$2"; shift 2 ;;
    --storage-driver)   STORAGE_DRIVER="$2"; shift 2 ;;
    --out)              OUT="$2"; shift 2 ;;
    --dry-run)          DRY_RUN=true; shift ;;
    --smtp-host)        SMTP_HOST_FLAG="$2"; shift 2 ;;
    --smtp-port)        SMTP_PORT_FLAG="$2"; shift 2 ;;
    --smtp-user)        SMTP_USER_FLAG="$2"; shift 2 ;;
    --smtp-pass)        SMTP_PASS_FLAG="$2"; shift 2 ;;
    --smtp-from)        SMTP_FROM_FLAG="$2"; shift 2 ;;
    --acme-email)       ACME_EMAIL_FLAG="$2"; shift 2 ;;
    -h|--help)          usage; trap - EXIT; exit 0 ;;
    *) log_err "Unknown flag: $1 (run with --help)"; exit 2 ;;
  esac
done

# ─── Validate inputs ─────────────────────────────────────────────────
if [ -z "$MODE" ]; then
  log_err "--mode required (tls | lan | ip | localhost). Run with --help."
  exit 2
fi

case "$MODE" in
  tls|lan)
    [ -z "$DOMAIN" ] && { log_err "--mode $MODE requires --domain (e.g. kauvery.example)"; exit 2; }
    if ! is_valid_domain "$DOMAIN"; then
      log_err "Invalid domain: '$DOMAIN' — must be like 'kauvery.example' or 'app.ohm.local'."
      exit 2
    fi
    ;;
  ip)
    [ -z "$HOST" ] && { log_err "--mode ip requires --host (e.g. 192.168.1.10)"; exit 2; }
    if ! is_valid_host "$HOST"; then
      log_err "Invalid host: '$HOST' — must be a valid IPv4 or hostname."
      exit 2
    fi
    ;;
  localhost)
    HOST="localhost"
    ;;
  *)
    log_err "Unknown mode: '$MODE' (use tls | lan | ip | localhost)"
    exit 2
    ;;
esac

case "$STORAGE_DRIVER" in
  s3|local) ;;
  *) log_err "--storage-driver must be 's3' or 'local' (got '$STORAGE_DRIVER')"; exit 2 ;;
esac

if [[ ! "$RELEASE_VERSION" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  log_err "Invalid --version: '$RELEASE_VERSION'. Expected vX.Y.Z."
  exit 2
fi

# Engine key check — warning only, not fatal (some setups want to run the
# wizard before the key arrives).
ENGINE_KEY_VALID=true
if ! is_valid_engine_key "$ENGINE_KEY"; then
  ENGINE_KEY_VALID=false
fi

# ─── Build mode-specific URLs ────────────────────────────────────────
case "$MODE" in
  tls)
    LANDING_URL="https://$DOMAIN"
    API_URL="https://api.$DOMAIN"
    WEB_URL="https://app.$DOMAIN"
    ADMIN_URL="https://admin.$DOMAIN"
    STUDIO_URL="https://studio.$DOMAIN"
    TOOLS_URL="https://tools.$DOMAIN"
    DOCS_URL="https://docs.$DOMAIN"
    COMPOSE_NOTE="Boot:  docker compose pull && docker compose --profile edge up -d"
    ;;
  lan)
    LANDING_URL="http://$DOMAIN:$LANDING_PORT"
    API_URL="http://api.$DOMAIN:$API_PORT"
    WEB_URL="http://app.$DOMAIN:$WEB_PORT"
    ADMIN_URL="http://admin.$DOMAIN:$ADMIN_PORT"
    STUDIO_URL="http://studio.$DOMAIN:$STUDIO_PORT"
    TOOLS_URL="http://tools.$DOMAIN:$TOOLS_PORT"
    DOCS_URL="http://docs.$DOMAIN:$DOCS_PORT"
    COMPOSE_NOTE="Boot:  docker compose pull && docker compose up -d   (no --profile edge — LAN has no TLS)"
    ;;
  ip)
    LANDING_URL="http://$HOST:$LANDING_PORT"
    API_URL="http://$HOST:$API_PORT"
    WEB_URL="http://$HOST:$WEB_PORT"
    ADMIN_URL="http://$HOST:$ADMIN_PORT"
    STUDIO_URL="http://$HOST:$STUDIO_PORT"
    TOOLS_URL="http://$HOST:$TOOLS_PORT"
    DOCS_URL="http://$HOST:$DOCS_PORT"
    COMPOSE_NOTE="Boot:  docker compose pull && docker compose up -d"
    ;;
  localhost)
    LANDING_URL="http://localhost:$LANDING_PORT"
    API_URL="http://localhost:$API_PORT"
    WEB_URL="http://localhost:$WEB_PORT"
    ADMIN_URL="http://localhost:$ADMIN_PORT"
    STUDIO_URL="http://localhost:$STUDIO_PORT"
    TOOLS_URL="http://localhost:$TOOLS_PORT"
    DOCS_URL="http://localhost:$DOCS_PORT"
    COMPOSE_NOTE="Boot:  docker compose pull && docker compose up -d   (single-laptop demo)"
    ;;
esac

# Sensible SMTP "from" default. For ip / localhost modes use a generic
# placeholder — hospital must replace before going live.
if [ -n "${DOMAIN:-}" ]; then
  DEFAULT_SMTP_FROM="OHM <noreply@$DOMAIN>"
else
  DEFAULT_SMTP_FROM="OHM <noreply@example.com>"
fi

# ─── Stage 1: read existing secrets so they survive reruns ───────────
EXISTING_POSTGRES_PW=$(read_existing POSTGRES_PASSWORD)
EXISTING_REDIS_PW=$(read_existing REDIS_PASSWORD)
EXISTING_MINIO_PW=$(read_existing MINIO_ROOT_PASSWORD)
EXISTING_JWT=$(read_existing JWT_SECRET)
EXISTING_PEPPER=$(read_existing STUDIO_API_KEY_PEPPER)
# Also preserve SMTP creds if the user already configured them.
EXISTING_SMTP_HOST=$(read_existing SMTP_HOST)
EXISTING_SMTP_PORT=$(read_existing SMTP_PORT)
EXISTING_SMTP_USER=$(read_existing SMTP_USER)
EXISTING_SMTP_PASS=$(read_existing SMTP_PASS)
EXISTING_SMTP_FROM=$(read_existing SMTP_FROM)
EXISTING_ALERTS=$(read_existing ALERT_RECIPIENTS)
EXISTING_CADDY_EMAIL=$(read_existing CADDY_ACME_EMAIL)

POSTGRES_PW="${EXISTING_POSTGRES_PW:-$(gen_secret_b64 32)}"
REDIS_PW="${EXISTING_REDIS_PW:-$(gen_secret_b64 24)}"
MINIO_PW="${EXISTING_MINIO_PW:-$(gen_secret_b64 24)}"
JWT_SECRET_VAL="${EXISTING_JWT:-$(gen_secret_b64 48)}"
PEPPER="${EXISTING_PEPPER:-$(gen_secret_hex 24)}"

if [ "$DRY_RUN" = true ]; then
  echo ""
  echo "──── DRY RUN — would write to $OUT ────"
  echo "  mode:            $MODE"
  echo "  ${DOMAIN:+domain:          $DOMAIN}"
  echo "  ${HOST:+host:            $HOST}"
  echo "  release version: $RELEASE_VERSION"
  echo "  storage driver:  $STORAGE_DRIVER"
  echo "  engine URL:      $ENGINE_URL"
  echo "  engine key:      $([ "$ENGINE_KEY_VALID" = true ] && echo "ok (length ${#ENGINE_KEY})" || echo "MISSING or placeholder")"
  echo "  doctor app:      $WEB_URL"
  echo "  admin:           $ADMIN_URL"
  echo "  studio:          $STUDIO_URL"
  echo "  tools:           $TOOLS_URL"
  echo "  landing:         $LANDING_URL"
  echo "  docs:            $DOCS_URL"
  echo "  api:             $API_URL"
  echo ""
  echo "  Re-run without --dry-run to write."
  trap - EXIT
  exit 0
fi

# ─── Stage 2: write the .env atomically ──────────────────────────────
rm -f "$OUT.tmp"

{
  echo "# ════════════════════════════════════════════════════════════════════"
  echo "# OHM — Root .env (generated by deploy/hospital/setup.sh)"
  echo "# Mode:        $MODE"
  case "$MODE" in
    tls|lan)   echo "# Domain:      $DOMAIN" ;;
    ip)        echo "# Host:        $HOST" ;;
    localhost) echo "# Host:        localhost (single-machine demo)" ;;
  esac
  echo "# Storage:     $STORAGE_DRIVER"
  echo "# Generated:   $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "# Re-run setup.sh anytime to refresh URLs without churning secrets."
  echo "# ════════════════════════════════════════════════════════════════════"
  echo ""
  echo "# ─── Atomic release version (single source of truth) ──────────────"
  echo "# Every service in docker-compose.yml interpolates this — bump it"
  echo "# and run ./upgrade.sh to atomically update the whole stack."
  echo "RELEASE_VERSION=$RELEASE_VERSION"
  echo ""
  echo "# ─── Topology metadata (read by verify.sh / upgrade.sh) ───────────"
  echo "OHM_MODE=$MODE"
  echo "OHM_API_URL=$API_URL"
  echo ""
  echo "# ─── Public URLs (CORS allow-list + email links + landing CTAs) ───"
  echo "LANDING_URL=$LANDING_URL"
  echo "FRONTEND_URL=$WEB_URL"
  echo "ADMIN_URL=$ADMIN_URL"
  echo "STUDIO_URL=$STUDIO_URL"
  echo "TOOLS_URL=$TOOLS_URL"
  echo "DOCS_URL=$DOCS_URL"
  echo ""
  echo "# ─── Vite SPA build args (baked default — overridden at runtime by"
  echo "#     ./config/<spa>-config.js mounted into each container) ────────"
  echo "VITE_API_BASE_URL=$API_URL"
  echo "VITE_DOCTOR_APP_URL=$WEB_URL"
  echo "VITE_ADMIN_APP_URL=$ADMIN_URL"
  echo "VITE_TOOLS_URL=$TOOLS_URL"
  echo "VITE_DOCS_URL=$DOCS_URL"
  echo ""
  echo "# ─── OHM Engine connection (hospital → OHM) ───────────────────────"
  echo "OHM_ENGINE_URL=$ENGINE_URL"
  echo "OHM_ENGINE_API_KEY=$ENGINE_KEY"
  echo ""
  echo "# ─── Bundled infra (auto-generated, stable across reruns) ─────────"
  echo "POSTGRES_USER=postgres"
  echo "POSTGRES_PASSWORD=$POSTGRES_PW"
  echo "POSTGRES_DB=ohm"
  echo "REDIS_PASSWORD=$REDIS_PW"
  echo "REDIS_HOST=redis"
  echo "REDIS_PORT=6379"
  echo "MINIO_ROOT_USER=ohm-admin"
  echo "MINIO_ROOT_PASSWORD=$MINIO_PW"
  echo "OHM_S3_BUCKET=ohm-audio"
  echo ""
  echo "# ─── Hospital API runtime config ──────────────────────────────────"
  echo "DATABASE_URL=postgresql://postgres:$POSTGRES_PW@postgres:5432/ohm"
  echo "JWT_EXPIRATION=20m"
  echo "REFRESH_TOKEN_EXPIRATION=30d"
  echo "STUDIO_DEFAULT_RATE_LIMIT_PER_MIN=60"
  echo "STUDIO_MAX_AUDIO_BYTES=104857600"
  echo "AUDIO_MAX_UPLOAD_MB=2048"
  echo "API_JSON_BODY_MB=50"
  echo "AUDIO_DEBUG=0"
  echo "AUDIO_DEBUG_VERBOSE=0"
  echo "LLM_HOURLY_QUOTA_PER_USER=60"
  echo "USAGE_LLM_INR_PER_1K_TOKENS=0.5"
  echo "USAGE_STT_INR_PER_MINUTE=1.0"
  echo "DEFAULT_BRAND_NAME=OHM — Open Holistic Medicine"
  echo ""
  echo "# ─── Object storage ───────────────────────────────────────────────"
  echo "# 's3' = bundled MinIO (default; recommended). 'local' = multer disk"
  echo "# (good for single-server clinics with limited memory)."
  echo "STORAGE_DRIVER=$STORAGE_DRIVER"
  echo "S3_ENDPOINT=http://minio:9000"
  echo "S3_REGION=us-east-1"
  echo "S3_BUCKET=ohm-audio"
  echo "S3_ACCESS_KEY=ohm-admin"
  echo "S3_SECRET_KEY=$MINIO_PW"
  echo "S3_FORCE_PATH_STYLE=true"
  echo ""
  echo "# No LLM env vars at the hospital — every AI feature (transcribe,"
  echo "# extract, chat with tools, codes, Studio playgrounds) goes through"
  echo "# the OHM Engine via OHM_ENGINE_URL + OHM_ENGINE_API_KEY above."
  echo ""
  echo "# ─── Auth secrets (auto-generated; rotation invalidates sessions) ─"
  echo "JWT_SECRET=$JWT_SECRET_VAL"
  echo "STUDIO_API_KEY_PEPPER=$PEPPER"
  echo ""
  echo "# ─── SMTP (required for invite + password-reset emails) ──────────"
  # Flag wins over existing value wins over blank default.
  echo "SMTP_HOST=${SMTP_HOST_FLAG:-${EXISTING_SMTP_HOST:-}}"
  echo "SMTP_PORT=${SMTP_PORT_FLAG:-${EXISTING_SMTP_PORT:-587}}"
  echo "SMTP_USER=${SMTP_USER_FLAG:-${EXISTING_SMTP_USER:-}}"
  echo "SMTP_PASS=${SMTP_PASS_FLAG:-${EXISTING_SMTP_PASS:-}}"
  echo "SMTP_FROM=\"${SMTP_FROM_FLAG:-${EXISTING_SMTP_FROM:-$DEFAULT_SMTP_FROM}}\""
  echo ""
  echo "# ─── Operations ──────────────────────────────────────────────────"
  echo "ALERT_RECIPIENTS=${EXISTING_ALERTS:-}"
  if [ "$MODE" = "tls" ]; then
    echo ""
    echo "# ─── Caddy (Let's Encrypt cert-expiry notifications) ────────────"
    echo "CADDY_ACME_EMAIL=${ACME_EMAIL_FLAG:-${EXISTING_CADDY_EMAIL:-hospital-it@$DOMAIN}}"
  fi
} > "$OUT.tmp"

# Atomic move + 0600 permissions so secrets aren't world-readable.
mv "$OUT.tmp" "$OUT"
chmod 600 "$OUT"

# ─── Stage 3: generate per-SPA runtime config.js ─────────────────────
CONFIG_DIR="$(dirname "$OUT")/config"
mkdir -p "$CONFIG_DIR"
chmod 700 "$CONFIG_DIR"

write_config_js() {
  local file="$1"; shift
  {
    echo "// Generated by setup.sh — mode=$MODE — $(date -u +%Y-%m-%dT%H:%M:%SZ)."
    echo "// Edit by re-running setup.sh, not by hand."
    echo "window.__OHM_CONFIG__ = {"
    while [ $# -gt 0 ]; do
      printf '  %s: %s,\n' "$1" "$2"
      shift 2
    done
    echo "};"
  } > "$file"
}
quote() { printf '"%s"' "$1"; }

write_config_js "$CONFIG_DIR/web-config.js" \
  apiBaseUrl   "$(quote "$API_URL")" \
  adminAppUrl  "$(quote "$ADMIN_URL")" \
  docsUrl      "$(quote "$DOCS_URL")" \
  toolsUrl     "$(quote "$TOOLS_URL")"

write_config_js "$CONFIG_DIR/admin-config.js" \
  apiBaseUrl   "$(quote "$API_URL")" \
  doctorAppUrl "$(quote "$WEB_URL")" \
  toolsUrl     "$(quote "$TOOLS_URL")"

write_config_js "$CONFIG_DIR/studio-config.js" \
  apiBaseUrl   "$(quote "$API_URL")" \
  docsUrl      "$(quote "$DOCS_URL")"

write_config_js "$CONFIG_DIR/tools-config.js" \
  apiBaseUrl   "$(quote "$API_URL")" \
  docsUrl      "$(quote "$DOCS_URL")"

write_config_js "$CONFIG_DIR/landing-config.js" \
  apiBaseUrl   "$(quote "$API_URL")" \
  doctorAppUrl "$(quote "$WEB_URL")" \
  adminAppUrl  "$(quote "$ADMIN_URL")" \
  studioUrl    "$(quote "$STUDIO_URL")" \
  docsUrl      "$(quote "$DOCS_URL")"

# ─── Stage 4: generate Caddyfile (tls mode only) ─────────────────────
if [ "$MODE" = "tls" ]; then
  CADDY_FILE="$(dirname "$OUT")/Caddyfile"
  {
    echo "# Generated by setup.sh — domain=$DOMAIN — $(date -u +%Y-%m-%dT%H:%M:%SZ)."
    echo "# Caddy auto-issues per-subdomain Let's Encrypt certs via HTTP-01."
    echo "# If port 80 inbound is blocked, switch to DNS-01 — see"
    echo "# https://caddyserver.com/docs/automatic-https#dns-challenge"
    echo ""
    echo "(common_headers) {"
    echo "  header {"
    echo '    Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"'
    echo '    X-Content-Type-Options "nosniff"'
    echo '    X-Frame-Options "DENY"'
    echo '    Referrer-Policy "no-referrer"'
    echo "  }"
    echo "}"
    echo ""
    for entry in "app:web:80" "admin:admin:80" "studio:studio:80" "tools:tools:80" "docs:docs:3000"; do
      sub="${entry%%:*}"
      svc="$(echo "$entry" | cut -d: -f2)"
      port="$(echo "$entry" | cut -d: -f3)"
      echo "$sub.$DOMAIN {"
      echo "  reverse_proxy $svc:$port"
      echo "  encode zstd gzip"
      echo "  import common_headers"
      echo "}"
      echo ""
    done
    echo "$DOMAIN {"
    echo "  reverse_proxy landing:80"
    echo "  encode zstd gzip"
    echo "  import common_headers"
    echo "}"
    echo ""
    echo "www.$DOMAIN {"
    echo "  redir https://$DOMAIN{uri}"
    echo "}"
    echo ""
    echo "api.$DOMAIN {"
    echo "  reverse_proxy api:4000"
    echo "  encode zstd gzip"
    echo "  import common_headers"
    echo "  # Long audio uploads (up to 500 MB SDK cap)."
    echo "  request_body {"
    echo "    max_size 600MB"
    echo "  }"
    echo "}"
  } > "$CADDY_FILE"
  chmod 644 "$CADDY_FILE"
  log_ok "Wrote $CADDY_FILE"
fi

# ─── Stage 5: warnings ───────────────────────────────────────────────
trap - EXIT  # everything past here is best-effort
echo ""
echo "══════════════════════════════════════════════════════════════════"
echo "  ✓ Wrote $OUT  ($(wc -l < "$OUT" | tr -d ' ') lines, mode=$MODE, chmod 600)"
echo "  ✓ Wrote $CONFIG_DIR/{web,admin,studio,tools,landing}-config.js"
echo "══════════════════════════════════════════════════════════════════"
echo ""
echo "Hospital URLs:"
echo "  Doctor app:  $WEB_URL"
echo "  Admin:       $ADMIN_URL"
echo "  Studio:      $STUDIO_URL"
echo "  Tools:       $TOOLS_URL"
echo "  Landing:     $LANDING_URL"
echo "  Docs:        $DOCS_URL"
echo "  API:         $API_URL"
echo ""
echo "$COMPOSE_NOTE"
echo ""

if [ "$ENGINE_KEY_VALID" = false ]; then
  log_warn "OHM_ENGINE_API_KEY is empty or a placeholder."
  log_warn "  AI features will return 502 ENGINE_VENDOR_UNAVAILABLE until set."
  log_warn "  Request your key from info@ohm.doctor, then:"
  log_warn "    \$EDITOR $OUT     # paste into OHM_ENGINE_API_KEY=..."
  log_warn "    docker compose restart api"
  echo ""
fi

FINAL_SMTP_HOST="${SMTP_HOST_FLAG:-${EXISTING_SMTP_HOST:-}}"
if [ -z "$FINAL_SMTP_HOST" ]; then
  log_warn "SMTP is not configured — doctor invites + password resets won't deliver."
  log_warn "  Re-run setup.sh with --smtp-host/--smtp-user/--smtp-pass, OR"
  log_warn "  edit $OUT and fill in SMTP_HOST / SMTP_USER / SMTP_PASS."
  echo ""
fi

case "$MODE" in
  lan)
    echo "Your hospital DNS must resolve these names to the server's LAN IP:"
    for sub in app admin studio tools docs api ""; do
      [ -z "$sub" ] && echo "  $DOMAIN" || echo "  $sub.$DOMAIN"
    done
    echo ""
    ;;
  ip)
    echo "Tip: assign a static IP or DHCP reservation for this server. If"
    echo "the IP changes later, re-run this wizard with the new --host and"
    echo "restart the SPAs:   docker compose restart web admin studio tools landing"
    echo ""
    ;;
  localhost)
    echo "Localhost mode is single-laptop only. Other devices can't reach"
    echo "'localhost'. For shared use, re-run with --mode ip or --mode lan."
    echo ""
    ;;
esac

echo "Need anything from OHM? Email info@ohm.doctor."
